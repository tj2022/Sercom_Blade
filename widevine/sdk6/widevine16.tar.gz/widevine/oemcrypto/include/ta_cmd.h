/*
 * Copyright (c) 2014, Linaro Limited
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef TA_MODULAR_WIDEVINE_H
#define TA_MODULAR_WIDEVINE_H

/* This UUID is generated with uuidgen
   the ITU-T UUID generator at http://www.itu.int/ITU-T/asn1/uuid.html */
#define TA_WIDEVINE_MODULAR_LEVEL1_UUID { 0xa2b91020, 0x083e, 0x11e5, \
        { 0x9a, 0xed, 0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b} }

#define TA_HDCP14_UUID { 0x87ef28e8, 0xf581, 0x4e3d, \
	{ 0xb2, 0xb2, 0xd7, 0xe3, 0xd4, 0x8b, 0x23, 0x21} }
#define TA_HDCP_UUID { 0x8baaf200, 0x2450, 0x11e4, \
	{ 0xab, 0xe2, 0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b} }

#define TA_SECURITY_LEVEL1  1
#define TA_SECURITY_LEVEL2  2
#define TA_SECURITY_LEVEL3  3

typedef enum
{
    TA_TEE_Initialize,
    TA_TEE_Terminate,
    TA_TEE_OpenSession,
    TA_TEE_CloseSession,
    TA_TEE_GenerateNonce,
    TA_TEE_GenerateDerivedKeys,
    TA_TEE_GenerateSignature,
    TA_TEE_LoadKeys_A,
    TA_TEE_LoadKeys_B,
    TA_TEE_LoadKeys_C,
    TA_TEE_RefreshKeys_A,
    TA_TEE_RefreshKeys_B,
    TA_TEE_SelectKey,
    TA_TEE_DecryptCTR,
    TA_TEE_DecryptCTR_Virtual,
    TA_TEE_InstallKeybox,
    TA_TEE_IsKeyboxValid,
    TA_TEE_GetDeviceID,
    TA_TEE_GetKeyData,
    TA_TEE_GetRandom,
    TA_TEE_WrapKeybox,
    TA_TEE_RewrapDeviceRSAKey_A,
    TA_TEE_RewrapDeviceRSAKey_B,
    TA_TEE_LoadDeviceRSAKey,
    TA_TEE_GenerateRSASignature,
    TA_TEE_DeriveKeysFromSessionKey,
    TA_TEE_Generic_Encrypt,
    TA_TEE_Generic_Decrypt,
    TA_TEE_Generic_Sign,
    TA_TEE_Generic_Verify,
    TA_TEE_Memcpy_va,
    TA_TEE_Memcpy_pa,
    TA_TEE_QueryKeyControl,
    TA_TEE_DecryptCTR_A7,
    TA_TEE_Memcpy_A7,
    TA_TEE_SelectKey_for_v14,
    TA_TEE_MacKeysUsage,
    TA_TEE_CheckUsageEntry,
    TA_TEE_LoadEntitledContentKeys_old,
    TA_TEE_RewrapDeviceRSAKey,
    TA_TEE_LoadCasECMKeys_v14,
    TA_TEE_SetCasSocData,
    TA_TEE_GetOEMPublicCertificate,
    TA_TEE_RewrapDeviceRSAKey30,
    TA_TEE_LoadTestKeybox,
    TA_TEE_GetHDCPCapability,
    TA_TEE_LoadEntitledContentKeys,
    TA_TEE_ExtractPESHeaderInfo,
    TA_TEE_LoadCasECMKeys,
    TA_TEE_Descramble,
    TA_CMD_MAX
} ta_cmd_e;


typedef enum {
    TA_CMD_RET_SUCCESS                            = 0,
    TA_CMD_RET_ERROR_INIT_FAILED                  = 1,
    TA_CMD_RET_ERROR_TERMINATE_FAILED             = 2,
    TA_CMD_RET_ERROR_OPEN_FAILURE                 = 3,
    TA_CMD_RET_ERROR_CLOSE_FAILURE                = 4,
    TA_CMD_RET_ERROR_ENTER_SECURE_PLAYBACK_FAILED = 5,
    TA_CMD_RET_ERROR_EXIT_SECURE_PLAYBACK_FAILED  = 6,
    TA_CMD_RET_ERROR_SHORT_BUFFER                 = 7,
    TA_CMD_RET_ERROR_NO_DEVICE_KEY                = 8,
    TA_CMD_RET_ERROR_NO_ASSET_KEY                 = 9,
    TA_CMD_RET_ERROR_KEYBOX_INVALID               = 10,
    TA_CMD_RET_ERROR_NO_KEYDATA                   = 11,
    TA_CMD_RET_ERROR_NO_CW                        = 12,
    TA_CMD_RET_ERROR_DECRYPT_FAILED               = 13,
    TA_CMD_RET_ERROR_WRITE_KEYBOX                 = 14,
    TA_CMD_RET_ERROR_WRAP_KEYBOX                  = 15,
    TA_CMD_RET_ERROR_BAD_MAGIC                    = 16,
    TA_CMD_RET_ERROR_BAD_CRC                      = 17,
    TA_CMD_RET_ERROR_NO_DEVICEID                  = 18,
    TA_CMD_RET_ERROR_RNG_FAILED                   = 19,
    TA_CMD_RET_ERROR_RNG_NOT_SUPPORTED            = 20,
    TA_CMD_RET_ERROR_SETUP                        = 21,
    TA_CMD_RET_ERROR_OPEN_SESSION_FAILED          = 22,
    TA_CMD_RET_ERROR_CLOSE_SESSION_FAILED         = 23,
    TA_CMD_RET_ERROR_INVALID_SESSION              = 24,
    TA_CMD_RET_ERROR_NOT_IMPLEMENTED              = 25,
    TA_CMD_RET_ERROR_NO_CONTENT_KEY               = 26,
    TA_CMD_RET_ERROR_CONTROL_INVALID              = 27,
    TA_CMD_RET_ERROR_UNKNOWN_FAILURE              = 28,
    TA_CMD_RET_ERROR_INVALID_CONTEXT              = 29,
    TA_CMD_RET_ERROR_SIGNATURE_FAILURE            = 30,
    TA_CMD_RET_ERROR_TOO_MANY_SESSIONS            = 31,
    TA_CMD_RET_ERROR_INVALID_NONCE                = 32,
    TA_CMD_RET_ERROR_TOO_MANY_KEYS                = 33,
    TA_CMD_RET_ERROR_DEVICE_NOT_RSA_PROVISIONED   = 34,
    TA_CMD_RET_ERROR_INVALID_RSA_KEY              = 35,
    TA_CMD_RET_ERROR_KEY_EXPIRED                  = 36,
    TA_CMD_RET_ERROR_INSUFFICIENT_RESOURCES       = 37,
} TA_CMD_RET_Result;

#ifdef __TA__
#define SET_TA_RET(x) ((x==TA_CMD_RET_SUCCESS)?TEE_SUCCESS:(0xF57E0000|x))
#endif
#ifdef __CLIENT__
#define GET_TA_RET(x) ((x&(~0xF57EFFFF))?TEEC_ERROR_GENERIC:(x&0x0000FFFF))
#endif

#endif /*TA_HELLO_WORLD_H*/
