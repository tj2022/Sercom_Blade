// Widevine CE CDM Version
#ifndef CDM_VERSION
# define CDM_VERSION "16.4.0"
#endif
#define EME_VERSION "https://www.w3.org/TR/2017/REC-encrypted-media-20170918"
