/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef _DRMSCTEEINTERNAL_H_
#define _DRMSCTEEINTERNAL_H_ 1

#include <drmsecurecore.h>
#include <drmteeproxy.h>

ENTER_PK_NAMESPACE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_SECURECORE_TEE_IMPL_GetNKB(
    __in                              const DRM_SECURECORE_TEE_DATA *f_pTeeData,
    __in                              const DRM_ID                  *f_pLID,
    __out                                   DRM_TEE_BYTE_BLOB       *f_pNKBWeakRef ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL DRM_SECURECORE_TEE_IMPL_GetVersionInformation(
    __in                                              const DRM_TEE_PROXY_CONTEXT      *f_pTeeCtx,
    __out_opt                                               DRM_SECURECORE_VERSIONINFO *f_pSecureCoreVerInfo,
    __out_ecount_opt( DRM_TEE_METHOD_FUNCTION_MAP_COUNT )   DRM_DWORD                  *f_pdwFunctionMap ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

#endif /* _DRMSCTEEINTERNAL_H_ */
