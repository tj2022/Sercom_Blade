/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRM_TOOLS_OEM_H
#define __DRM_TOOLS_OEM_H

#include <drmtypes.h>

#define MAX_HTTP_HEADER_SIZE          4096
#define MAX_REDIRECTIONS_PER_REQUEST  5
#define MAX_HTTP_RETRIES              3
#define MAX_URL_SIZE                  1024
#define AGENT_NAME                    "MSPR_PK_UTILITY"

/* HTTP status code of temporary redirection. */
#define HTTP_STATUS_TEMPORARY_REDIRECT  307
#define HTTP_STATUS_FOUND_REDIRECT      302

DRM_RESULT DRM_CALL DRM_TOOLS_OEM_DoHttpTransaction(
    _In_reads_or_z_( f_cchUrl + 1 )                         const DRM_CHAR             *f_pszUrl,
    __in                                                          DRM_DWORD             f_cchUrl,
    _In_reads_or_z_opt_( f_cchHttpHeader )                  const DRM_CHAR             *f_pszHttpHeader,
    __in                                                          DRM_DWORD             f_cchHttpHeader,
    __in_bcount_opt( f_cbChallenge )                        const DRM_BYTE             *f_pbChallenge,
    __in                                                          DRM_DWORD             f_cbChallenge,
    __in                                                          DRM_BOOL              f_fPost,
    __deref_out_bcount_z( *f_pcbResponse )                        DRM_BYTE            **f_ppbResponse,
    __out_ecount( 1 )                                             DRM_DWORD            *f_pcbResponse );

#endif /* __DRM_TOOLS_OEM_H */

