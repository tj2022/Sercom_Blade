/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRM_PROVISIONING_SERVER_H__
#define __DRM_PROVISIONING_SERVER_H__

#include <drmteerprov.h>

ENTER_PK_NAMESPACE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RPROV_Server_Mock(
        __in_bcount(f_cbRequest)                          const DRM_BYTE    *f_pbRequest,
        __in                                                    DRM_DWORD    f_cbRequest,
        __deref_out_bcount(*f_pcbResponse)                      DRM_BYTE   **f_ppbResponse,
        __out                                                   DRM_DWORD   *f_pcbResponse ) DRM_NO_INLINE_ATTRIBUTE;

#define PK_VERSION_COUNT 4
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RPROV_Server_ParseCertRequest(
    __in_bcount(f_cbRequest)                  const DRM_BYTE    *f_pbRequest,
    __in                                            DRM_DWORD    f_cbRequest,
    __in_bcount_opt(f_cbSessionKey)           const DRM_BYTE    *f_pbSessionKey,
    __in                                            DRM_DWORD    f_cbSessionKey,
    __in                                            DRM_BOOL     f_fOnlyCertReturned,
    __out                                           DRM_DWORD   *f_pdwOEMTEEVersion,
    __out_ecount(PK_VERSION_COUNT)                  DRM_DWORD   *f_pdwPKVersion,
    __out                                           DRM_ID      *f_pidHWId,
    __out                                           DRM_ID      *f_pidAppId,
    __deref_out_bcount_opt(*f_pcbModelAuthCert)     DRM_BYTE   **f_ppbModelAuthCert,
    __out_opt                                       DRM_DWORD   *f_pcbModelAuthCert,
    __deref_out_bcount_opt(*f_pcbModelNumber)       DRM_BYTE   **f_ppbModelNumber,
    __out_opt                                       DRM_DWORD   *f_pcbModelNumber,
    __deref_out_bcount_opt(*f_pcbManufacturer)      DRM_BYTE   **f_ppbManufacturer,
    __out_opt                                       DRM_DWORD   *f_pcbManufacturer,
    __deref_out_bcount_opt(*f_pcbModelName)         DRM_BYTE   **f_ppbModelName,
    __out_opt                                       DRM_DWORD   *f_pcbModelName,
    __out_opt                                       DRM_DWORD   *f_pdwSecurityLevel,
    __out                                           DRM_VOID   **f_ppvOpaqueRprovContext ) DRM_NO_INLINE_ATTRIBUTE;


DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RPROV_Server_CreateCert(
    __in                                                DRM_VOID    *f_pvOpaqueRprovContext,
    __in_bcount(f_cbModelNumber)                  const DRM_BYTE    *f_pbModelNumber,
    __in                                                DRM_DWORD    f_cbModelNumber,
    __in_bcount(f_cbManufacturer)                 const DRM_BYTE    *f_pbManufacturer,
    __in                                                DRM_DWORD    f_cbManufacturer,
    __in_bcount(f_cbModelName)                    const DRM_BYTE    *f_pbModelName,
    __in                                                DRM_DWORD    f_cbModelName,
    __in_bcount(f_cbHWID)                         const DRM_BYTE    *f_pbHWID,
    __in                                                DRM_DWORD    f_cbHWID,
    __in_bcount(f_cbModelCertificate)             const DRM_BYTE    *f_pbModelCertificate,
    __in                                                DRM_DWORD    f_cbModelCertificate,
    __in                                                DRM_DWORD    f_dwSecurityLevel,
    __deref_out_bcount(*f_pcbCertificateToSign)         DRM_BYTE   **f_ppbCertificateToSign,
    __out                                               DRM_DWORD   *f_pcbCertificateToSign );

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RPROV_Server_CreateResponse(
    __in                                                DRM_VOID    *f_pvOpaqueRprovContext,
    __in_bcount(f_cbCertSignature)                const DRM_BYTE    *f_pbCertSignature,
    __in                                                DRM_DWORD    f_cbCertSignature,
    __deref_out_bcount( *f_pcbResponse )                DRM_BYTE   **f_ppbResponse,
    __out                                               DRM_DWORD   *f_pcbResponse ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL DRM_RPROV_Server_ReleaseProvContext(
    __in_opt                                            DRM_VOID    *f_pvOpaqueRprovContext ) DRM_NO_INLINE_ATTRIBUTE;


DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RPROV_IMPL_DeriveKey(
    __in_ecount(DRM_AES_KEYSIZE_128)    const DRM_BYTE              f_pbKSession[DRM_AES_KEYSIZE_128],
    __out_ecount(DRM_AES_KEYSIZE_128)         DRM_BYTE              f_pbKKey[DRM_AES_KEYSIZE_128],
    __in                                      ProvisioningKeyType   f_eKeyType ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

#endif /* __DRM_PROVISIONING_SERVER_H__ */
