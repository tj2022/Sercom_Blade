/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __OEMPROVISIONINGSERVERMOCK_H__
#define __OEMPROVISIONINGSERVERMOCK_H__

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL OEM_RPROV_Server_Mock_UnwrapRequest(
    __in_ecount(f_cbRequest)                          const DRM_BYTE    *f_pbRequest,
    __in                                                    DRM_DWORD    f_cbRequest,
    __deref_out_ecount(*f_pcbUnwrappedRequest)              DRM_BYTE   **f_ppbUnwrappedRequest,
    __out                                                   DRM_DWORD   *f_pcbUnwrappedRequest,
    __out                                                   DRM_BOOL    *f_fKSessionNegotiated,
    __out                                                   DRM_BOOL    *f_pfOnlyCertReturned ) DRM_NO_INLINE_ATTRIBUTE;

#endif /* __OEMPROVISIONINGSERVERMOCK_H__ */