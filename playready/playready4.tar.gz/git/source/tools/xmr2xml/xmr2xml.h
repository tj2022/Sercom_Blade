/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __XMR2XML_H__
#define __XMR2XML_H__

#include <drmtypes.h>

DRM_RESULT DRM_CALL _PrintNameableGuid(
    __inout_bcount( f_cbXmlBuffer )       DRM_BYTE          *f_pbXmlBuffer,
    __in                                  DRM_DWORD          f_cbXmlBuffer,
    __in                            const DRM_GUID          *pGuid,
    __in                            const DRM_CONST_STRING  *pdstrLabel );

DRM_RESULT DateTimeToString( __in DRM_UINT64 f_u64DateTime, __out DRM_STRING *f_pdstrDateTime );

DRM_RESULT AddGenericValueToXml(
    __in_bcount( f_cbValue )  const DRM_BYTE             *f_pbValue,
    __in                            DRM_DWORD             f_cbValue,
    __in                      const DRM_CONST_STRING     *f_pdstrTagName,
    __inout_bcount( f_cbXml )       DRM_BYTE             *f_pbXml,
    __in                            DRM_DWORD             f_cbXml,
    __in                            DRM_BOOL              f_fAlsoDisplayAsDecimal,
    __in                            DRM_BOOL              f_fInNetworkByteOrder );

DRM_RESULT AddBLOBToXml(
    __in                            const DRM_CONST_STRING *f_pdstrTag,
    __in_bcount( f_cbTokenData )    const DRM_BYTE         *f_pbTokenData,
    __in                                  DRM_DWORD         f_cbTokenData,
    __inout_bcount( f_cbXmlBuffer )       DRM_BYTE         *f_pbXmlBuffer,
    __in                                  DRM_DWORD         f_cbXmlBuffer,
    __in                                  DRM_BOOL          f_fB64Encode );

DRM_RESULT FormatXmrAsXml(
    __in_ecount( f_cbXMR )   const DRM_BYTE       *f_pbXMR,
    __in                           DRM_DWORD       f_cbXMR,
    __out_ecount( f_cbXmlBuffer )  DRM_BYTE       *f_pbXmlBuffer,
    __in                           DRM_DWORD       f_cbXmlBuffer,
    __out_ecount( 1 )              DRM_STRING     *f_pdstrXml );

#endif /* __XMR2XML_H__ */
