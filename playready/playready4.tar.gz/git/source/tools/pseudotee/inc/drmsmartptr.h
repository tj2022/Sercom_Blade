/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMSMARTPTR_H__
#define __DRMSMARTPTR_H__

#if __MACINTOSH__
#include <thunks.h>
#else //__MACINTOSH__

#define DEFINE_MSPR_UUIDOF(T,guid)
#define DEFINE_MSPR_UUIDOF_IID(T)

#define MSPR_UUIDOF(Q) __uuidof(Q)

#endif //__MACINTOSH__

#include <drmdebug.h>

#include <Windows.h>
#include <mfapi.h>
#include <mfidl.h>

struct IMFContentProtectionDevice;
struct IMFContentDecryptorContext;

template <class T>
class _NoAddRefReleaseOnComSmartPtr : public T
{
private:
    STDMETHOD_(ULONG, AddRef)()=0;
    STDMETHOD_(ULONG, Release)()=0;
};

DRM_ALWAYS_INLINE IUnknown* ComSmartPtrAssign(IUnknown** pp, IUnknown* lp)
{
    if (lp != NULL)
    {
        lp->AddRef();
    }
    if (*pp)
    {
        (*pp)->Release();
    }
    *pp = lp;
    return lp;
}

template <class T>
class ComSmartPtr
{
public:
        typedef T _PtrClass;
PREFAST_PUSH_DISABLE_EXPLAINED( __WARNING_NO_MEMBERINIT_BEFORE_CONSTRUCTOR_BODY_25071, "Older compilers do not support initialization before constructor body" )
        DRM_ALWAYS_INLINE ComSmartPtr() : p( NULL ) {}
PREFAST_POP  /* __WARNING_NO_MEMBERINIT_BEFORE_CONSTRUCTOR_BODY_25071 */
        DRM_ALWAYS_INLINE ComSmartPtr(T* lp)
        {
                if ((p = lp) != NULL)
                        p->AddRef();
        }
        DRM_ALWAYS_INLINE ComSmartPtr(const ComSmartPtr<T>& lp)
        {
                if ((p = lp.p) != NULL)
                        p->AddRef();
        }
        DRM_ALWAYS_INLINE ~ComSmartPtr()
        {
                if (p)
                        p->Release();
        }
        DRM_ALWAYS_INLINE void Release()
        {
                T* pTemp = p;
                if (pTemp)
                {
                        p = NULL;
                        pTemp->Release();
                }
        }
        DRM_ALWAYS_INLINE operator T*() const
        {
                return (T*)p;
        }
        DRM_ALWAYS_INLINE T& operator*() const
        {
                DRMASSERT(p!=NULL);
                return *p;
        }
        //The ASSERT on operator& usually indicates a bug.  If this is really
        //what is needed, however, take the address of the p member explicitly.
        DRM_ALWAYS_INLINE T** operator&()
        {
                DRMASSERT(p==NULL);
                return &p;
        }
        DRM_ALWAYS_INLINE _NoAddRefReleaseOnComSmartPtr<T>* operator->() const
        {
                DRMASSERT(p!=NULL);
                return (_NoAddRefReleaseOnComSmartPtr<T>*)p;
        }
        DRM_ALWAYS_INLINE T* operator=(T* lp)
        {
            if( lp == NULL )
            {
                if( p )
                {
                    p->Release( );
                    p = NULL;
                }
                return NULL;
            }
            else
            {
                lp->AddRef( );
                if( p )
                {
                    p->Release( );
                }
                p = lp;
                return lp;
            }
        }
        DRM_ALWAYS_INLINE T* operator=(const ComSmartPtr<T>& lp)
        {
            if( lp.p == NULL )
            {
                if( p )
                {
                    p->Release( );
                    p = NULL;
                }
                return NULL;
            }
            else
            {
                lp.p->AddRef( );
                if( p )
                {
                    p->Release( );
                }
                p = lp.p;
            }
            return p;
        }
        DRM_ALWAYS_INLINE bool operator!() const
        {
                return (p == NULL);
        }
        DRM_ALWAYS_INLINE bool operator<(T* pT) const
        {
                return p < pT;
        }
        DRM_ALWAYS_INLINE bool operator==(T* pT) const
        {
                return p == pT;
        }
        // Compare two objects for equivalence
        bool IsEqualObject(IUnknown* pOther)
        {
                if (p == NULL && pOther == NULL)
                        return true; // They are both NULL objects

                if (p == NULL || pOther == NULL)
                        return false; // One is NULL the other is not

                ComSmartPtr<IUnknown> punk1;
                ComSmartPtr<IUnknown> punk2;
                p->QueryInterface(IID_IUnknown, (void**)&punk1);
                pOther->QueryInterface(IID_IUnknown, (void**)&punk2);
                return punk1 == punk2;
        }

        /**************************************************************************
        **
        ** Function  :  ComSmartPtr::AttachNoAddRef
        **
        ** Synopsis  :  Use this method to have the smart pointer take ownership
        **              of a raw pointer.
        **              For example, when an object is created with an initial
        **              refcount of one:
        **
        **              ComSmartPointer<IMyInterface> mySmart;
        **              mySmart.AttachNoAddRef( new CMyClass() );
        **              if( mySmart == NULL )
        **              {
        **                  hr = E_OUTOFMEMORY;
        **                  goto ErrorExit;
        **              }
        **
        ** Arguments :
        **              p2         Pointer to take ownership of
        **
        ** Returns   :
        **
        ** Notes     :  AddRef will NOT be called by this method.
        **
        **************************************************************************/
        DRM_ALWAYS_INLINE void AttachNoAddRef(T* p2)
        {
                if (p)
                        p->Release();
                p = p2;
        }

        /**************************************************************************
        **
        ** Function  :  ComSmartPtr::DetachNoRelease
        **
        ** Synopsis  :  Use this method to have the caller take ownership
        **              of a raw pointer.
        **              For example, a method that returns an object:
        **
        **              void MyMethod( IMyInterface **ppMyInterface )
        **              {
        **                  ComSmartPointer<IMyInterface> mySmart;
        **
        **                  ...initialize mySmart, e.g. as in the
        **                      AttachNoAddRef example...
        **
        **                  *ppMyInterface = mySmart.DetachNoRelease();
        **              }
        **
        **
        ** Arguments :
        **
        ** Returns   :  The raw pointer the caller will now own.
        **
        ** Notes     :  Release will NOT be called by this method.
        **
        **************************************************************************/
        DRM_ALWAYS_INLINE T* DetachNoRelease()
        {
                T* pt = p;
                p = NULL;
                return pt;
        }
        DRM_ALWAYS_INLINE HRESULT CopyTo(T** ppT)
        {
                DRMASSERT(ppT != NULL);
                if (ppT == NULL)
                        return E_POINTER;
                *ppT = p;
                if (p)
                        p->AddRef();
                return S_OK;
        }
        DRM_ALWAYS_INLINE HRESULT CoCreateInstance(REFCLSID rclsid, IUnknown * pUnkOuter = NULL, DWORD dwClsContext = CLSCTX_ALL)
        {
                DRMASSERT(p == NULL);
#if NO_WIN32_API_NAMESPACE_FUNCTIONS
                return ::CoCreateInstance(rclsid, pUnkOuter, dwClsContext, MSPR_UUIDOF(T), (void**)&p);
#else  //NO_WIN32_API_NAMESPACE_FUNCTIONS
                return Win32::CoCreateInstance(rclsid, pUnkOuter, dwClsContext, MSPR_UUIDOF(T), (void**)&p);
#endif //NO_WIN32_API_NAMESPACE_FUNCTIONS
        }
#if !__MACINTOSH__
        HRESULT CoCreateInstance(LPCOLESTR szProgID, IUnknown * pUnkOuter = NULL, DWORD dwClsContext = CLSCTX_ALL)
        {
                CLSID clsid;
                HRESULT hr = CLSIDFromProgID(szProgID, &clsid);
                DRMASSERT(p == NULL);
                if (SUCCEEDED(hr))
#if NO_WIN32_API_NAMESPACE_FUNCTIONS
                        hr = ::CoCreateInstance(clsid, pUnkOuter, dwClsContext, MSPR_UUIDOF(T), (void**)&p);
#else  //NO_WIN32_API_NAMESPACE_FUNCTIONS
                        hr = Win32::CoCreateInstance(clsid, pUnkOuter, dwClsContext, MSPR_UUIDOF(T), (void**)&p);
#endif //NO_WIN32_API_NAMESPACE_FUNCTIONS
                return hr;
        }
#endif //!__MACINTOSH__
        template <class Q>
        DRM_ALWAYS_INLINE HRESULT QueryInterface(Q** pp) const
        {
                DRMASSERT(pp != NULL && *pp == NULL);
                return p->QueryInterface(MSPR_UUIDOF(Q), (void**)pp);
        }
        T* p;
};

#endif //__DRMSMARTPTR_H__

