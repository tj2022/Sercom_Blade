/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __PSEUDOTEE_H__
#define __PSEUDOTEE_H__

#include <drmteetypes.h>

#if DRM_BUILD_PROFILE == DRM_BUILD_PROFILE_LINUX
#include <drmlinuxenv.h>
#else /* DRM_BUILD_PROFILE == DRM_BUILD_PROFILE_LINUX */
#include <drmwindowsenv.h>
extern const char g_pszPriteeUmdName[];
#endif /* DRM_BUILD_PROFILE == DRM_BUILD_PROFILE_LINUX */

#define DRM_TEE_BYTE_BLOB_WEAKREF {DRM_TEE_BYTE_BLOB_TYPE_WEAK_REF,0,0,NULL}

#define PRITEEUMD_ENTRYPOINT                    "PlayReady_UMD_MethodRequest"
#define PRITEEUMD_ENTRYPOINT_INIT               "OEM_TEE_PROXY_Initialize"
#define PRITEEUMD_ENTRYPOINT_UNINIT             "OEM_TEE_PROXY_Uninitialize"
#define PRITEEUMD_ENTRYPOINT_SERREQ             "OEM_TEE_PROXY_GetSerializationRequirements"
#define PRITEEUMD_ENTRYPOINT_INITHWKEY          "PlayReady_UMD_InitializeHardwareKey"
#define PRITEEUMD_ENTRYPOINT_TEST_SETPROP       "PlayReady_UMD_TEST_SetTeeProperty"
#define PRITEEUMD_PLAYREADY_SETBINNAME          "PlayReady_UMD_SetBinaryName"

#define PSEUDO_TEE_PROXY_MESSAGE_INPUT_HEADER_SIZE    0x18
#define PSEUDO_TEE_PROXY_MESSAGE_INPUT_FOOTER_SIZE    0x30
#define PSEUDO_TEE_PROXY_MESSAGE_OUTPUT_HEADER_SIZE   0x08
#define PSEUDO_TEE_PROXY_MESSAGE_OUTPUT_FOOTER_SIZE   0x28

typedef DRM_RESULT ( *LPFNDLL_PlayReady_UMD_MethodRequest) (
    __in                                                DRM_DWORD           f_dwFunctionMapOEMValue,
    __in                                                DRM_DWORD           f_cbInputHeaderSize,
    __in                                                DRM_DWORD           f_cbInputFooterSize,
    __in                                                DRM_DWORD           f_cbOutputHeaderSize,
    __in                                                DRM_DWORD           f_cbOutputFooterSize,
    __in                                                DRM_DWORD           f_cbRequestMessage,
    __in_bcount( f_cbRequestMessage )                   DRM_BYTE           *f_pbRequestMessage,
    __inout_opt                                         DRM_DWORD          *f_pcbResponseMessage,
    __inout_bcount_opt( *f_pcbResponseMessage )         DRM_BYTE           *f_pbResponseMessage );

typedef DRM_API DRM_RESULT( DRM_CALL *LPFNDLL_OEM_TEE_PROXY_GetSerializationRequirements ) (
    __in_opt                                DRM_VOID                                    *f_pvUserCtx,
    __out_ecount( 1 )                       DRM_TEE_PROXY_SERIALIZATION_REQUIREMENTS    *f_pRequirements );

typedef DRM_API DRM_RESULT( DRM_CALL *LPFNDLL_PlayReady_UMD_InitializeHardwareKey )(
    __in                                                DRM_DWORD           f_cbInputPrivateData,
    __in_bcount( f_cbInputPrivateData )           const DRM_BYTE           *f_pInputPrivateData,
    __out                                               DRM_UINT64         *f_pOutputPrivateData );

typedef DRM_API DRM_RESULT( DRM_CALL *LPFNDLL_PlayReady_UMD_TEST_SetTeeProperty )(
    __in                                                DRM_TEE_PROPERTY    f_eTeeProperty,
    __in                                                DRM_BOOL            f_fEnabled );

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL PlayReady_TEST_SetTeeProperty(
    __in                                                DRM_TEE_PROPERTY    f_eTeeProperty,
    __in                                                DRM_BOOL            f_fEnabled );

typedef char** CHAR_STAR_STAR;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL PlayReady_Structured_TEE_AES128CTR_DecryptContent(
    __in                                    DRM_DWORD                    f_cbMethodRequest,
    __in_bcount( f_cbMethodRequest )  const DRM_BYTE                    *f_pbMethodRequest,
    __in                                    DRM_DWORD                    f_cbMethodResponse,
    __inout_bcount( f_cbMethodResponse )    DRM_BYTE                    *f_pbMethodResponse ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL PlayReady_Structured_TEE_H264_PreProcessEncryptedData(
    __in                                    DRM_DWORD                    f_cbMethodRequest,
    __in_bcount( f_cbMethodRequest )  const DRM_BYTE                    *f_pbMethodRequest,
    __in                                    DRM_DWORD                    f_cbMethodResponse,
    __inout_bcount( f_cbMethodResponse )    DRM_BYTE                    *f_pbMethodResponse ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL PlayReady_Structured_TEE_AES128CTR_DecryptAudioContentMultiple(
    __in                                    DRM_DWORD                    f_cbMethodRequest,
    __in_bcount( f_cbMethodRequest )  const DRM_BYTE                    *f_pbMethodRequest,
    __in                                    DRM_DWORD                    f_cbMethodResponse,
    __inout_bcount( f_cbMethodResponse )    DRM_BYTE                    *f_pbMethodResponse ) DRM_NO_INLINE_ATTRIBUTE;

#endif // __PSEUDOTEE_H__

