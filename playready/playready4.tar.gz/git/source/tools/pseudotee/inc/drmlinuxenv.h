/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRM_LINUX_ENV_H__
#define __DRM_LINUX_ENV_H__

#include <drmcompiler.h>

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>

#define BOOL                DRM_BOOL
#define HINSTANCE           DRM_VOID*
#define LoadLibrary(x)      dlopen(x, RTLD_NOW)
#define LoadLibraryA(x)     LoadLibrary(x)

/*
** This macro assumes the library is in the current working directory (PWD)
** and loads the library using its full path instead of a relative path
*/
#define PRLoadLibraryA(dllpath,h)   DRM_DO {                        \
    DRM_CHAR rgchFile[ DRM_MAX_PATH ] = { 0 };                      \
    const DRM_CHAR *pwd = getenv( "PWD" );                          \
    DRM_DWORD len;                                                  \
    ChkBOOL( pwd != NULL, DRM_E_FAIL );                             \
    len = strlen( pwd );                                            \
    ChkBOOL( len > 0, DRM_E_FAIL );                                 \
    MEMCPY( rgchFile, pwd, len );                                   \
    rgchFile[ len ] = '/';                                          \
    MEMCPY( &rgchFile[ len + 1 ], dllpath, strlen( dllpath ) );     \
    h = LoadLibrary( rgchFile );                                    \
} DRM_WHILE_FALSE

#define GetProcAddress(x,y)     dlsym(x, (const DRM_CHAR*)y)
#define FreeLibrary(x)          dlclose(x)

#define ChkWR(x) DRM_DO {                                           \
    if( !(x) )                                                      \
    {                                                               \
        const char *err = dlerror();                                      \
        if( err != NULL )                                           \
        {                                                           \
            printf( "%s", err );                                    \
            printf( "\n" );                                         \
        }                                                           \
        ChkDR( DRM_E_FAIL );                                        \
    }                                                               \
} DRM_WHILE_FALSE

#define _snprintf(psz, cch, fmt, ... )      snprintf(psz, cch, fmt, __VA_ARGS__ )
#define Sleep(x)                            sleep(x/1000)
#define HRESULT                             DRM_RESULT

#endif /* __DRM_LINUX_ENV_H__ */

