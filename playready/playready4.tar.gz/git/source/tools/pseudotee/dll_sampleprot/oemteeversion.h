/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef _OEMTEEVERSION_H_
#define _OEMTEEVERSION_H_

ENTER_PK_NAMESPACE;

/* this turns on sample protection in oemteeversion.c */
#define SUPPORTS_SAMPLE_PROTECTION 1

EXIT_PK_NAMESPACE;

#endif /* _OEMTEEVERSION_H_ */
