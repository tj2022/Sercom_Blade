/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __PRITEE_UMD_H__
#define __PRITEE_UMD_H__

#if !defined(TARGET_LITTLE_ENDIAN) && !defined(BIG_ENDIAN)
#define TARGET_LITTLE_ENDIAN 1
#define BIG_ENDIAN           0
#elif defined(TARGET_LITTLE_ENDIAN) && !defined(BIG_ENDIAN)
#define BIG_ENDIAN !TARGET_LITTLE_ENDIAN
#elif defined(BIG_ENDIAN) && !defined(TARGET_LITTLE_ENDIAN)
#define TARGET_LITTLE_ENDIAN !BIG_ENDIAN
#endif

#define MEMSET memset
#define MEMCPY memcpy

#define UMD_CB_FROM_BLOB(b)   ((b)->oData.oBlob.cbData)
#define UMD_PB_FROM_BLOB(m,b) ((b)->oData.oBlob.cbData > 0 ? &(m)->pbMessage[(b)->oData.oBlob.ibData] : NULL)

#define MESSAGE_SERIALIZER_VERSION 1

#if TARGET_LITTLE_ENDIAN

#define DEFINE_FOUR_BYTE_FORMAT_ID( ch0, ch1, ch2, ch3 )                       \
    ((DRM_DWORD)(DRM_BYTE)(ch0)        | ((DRM_DWORD)(DRM_BYTE)(ch1) <<  8) | \
    ((DRM_DWORD)(DRM_BYTE)(ch2) << 16) | ((DRM_DWORD)(DRM_BYTE)(ch3) << 24))

#else /* TARGET_LITTLE_ENDIAN */

#define DEFINE_FOUR_BYTE_FORMAT_ID( ch0, ch1, ch2, ch3 )                       \
    ((DRM_DWORD)(DRM_BYTE)(ch3)        | ((DRM_DWORD)(DRM_BYTE)(ch2) <<  8) | \
    ((DRM_DWORD)(DRM_BYTE)(ch1) << 16) | ((DRM_DWORD)(DRM_BYTE)(ch0) << 24))

#endif /* TARGET_LITTLE_ENDIAN */

#define MARKER_VALUE() DEFINE_FOUR_BYTE_FORMAT_ID('P','R','X','Y')

#ifndef DRM_TEE_PROXY_PARAMETER_TYPE_SIZE
#define DRM_TEE_PROXY_PARAMETER_TYPE_SIZE                    (sizeof(DRM_DWORD) * 6)
#define DRM_TEE_PROXY_PARAMETER_TYPE__TYPE_OFFSET            (sizeof(DRM_DWORD) * 0)
#define DRM_TEE_PROXY_PARAMETER_TYPE__PARAMINDEX_OFFSET      (sizeof(DRM_DWORD) * 1)
#define DRM_TEE_PROXY_PARAMETER_TYPE__DWVALUE_OFFSET         (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__QWVALUE_OFFSET         (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__IDVALUE_OFFSET         (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__TEECTX_CB_OFFSET       (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__TEECTX_IB_OFFSET       (sizeof(DRM_DWORD) * 3)
#define DRM_TEE_PROXY_PARAMETER_TYPE__BLOB_TYPE_OFFSET       (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__BLOB_SUBTYPE_OFFSET    (sizeof(DRM_DWORD) * 3)
#define DRM_TEE_PROXY_PARAMETER_TYPE__BLOB_CB_OFFSET         (sizeof(DRM_DWORD) * 4)
#define DRM_TEE_PROXY_PARAMETER_TYPE__BLOB_IB_OFFSET         (sizeof(DRM_DWORD) * 5)
#define DRM_TEE_PROXY_PARAMETER_TYPE__DWORDLIST_CDW_OFFSET   (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__DWORDLIST_IB_OFFSET    (sizeof(DRM_DWORD) * 3)
#define DRM_TEE_PROXY_PARAMETER_TYPE__DWORDLIST_FLAG_OFFSET  (sizeof(DRM_DWORD) * 4)
#define DRM_TEE_PROXY_PARAMETER_TYPE__QWORDLIST_CQW_OFFSET   (sizeof(DRM_DWORD) * 2)
#define DRM_TEE_PROXY_PARAMETER_TYPE__QWORDLIST_IB_OFFSET    (sizeof(DRM_DWORD) * 3)
#define DRM_TEE_PROXY_PARAMETER_TYPE__QWORDLIST_FLAG_OFFSET  (sizeof(DRM_DWORD) * 4)
#endif

typedef enum __tagDRM_TEE_PROXY_PARAM_TYPE
{
    PARAMETER_TYPE_CONTEXT   = 1,
    PARAMETER_TYPE_DWORD     = 2,
    PARAMETER_TYPE_QWORD     = 3,
    PARAMETER_TYPE_ID        = 4,
    PARAMETER_TYPE_BLOB      = 5,
    PARAMETER_TYPE_DWORDLIST = 6,
    PARAMETER_TYPE_QWORDLIST = 7,
} DRM_TEE_PROXY_PARAM_TYPE;

typedef enum __tagDRM_TEE_PROXY_DWORDLIST_FLAG
{
    DRM_TEE_PROXY_DWORDLIST_FLAG_NONE      = 0,
    DRM_TEE_PROXY_DWORDLIST_FLAG_BIGENDIAN = 1,
} DRM_TEE_PROXY_DWORDLIST_FLAG;

typedef enum __tagDRM_TEE_PROXY_QWORDLIST_FLAG
{
    DRM_TEE_PROXY_QWORDLIST_FLAG_NONE      = 0,
    DRM_TEE_PROXY_QWORDLIST_FLAG_BIGENDIAN = 1,
} DRM_TEE_PROXY_QWORDLIST_FLAG;

#define ID_SIZE (16)

typedef struct __tagMessageHeader
{
    DRM_DWORD dwMarker;     /* This is a marker used to indicate this buffer is a valid serialized buffer.                                */
    DRM_DWORD dwVersion;    /* The version of the serializer that created the message buffer.                                             */
    DRM_DWORD dwMethodID;   /* The OEM defined method ID of the PRITEE method invocation.                                                 */
    DRM_DWORD dwResult;     /* This will hold the result of the PRITEE method invocation.                                                 */
    DRM_DWORD cParamters;   /* This is the count of parameters included in the response / request message.                                */
    DRM_DWORD ibFreeOffset; /* The offset into the response message to the free memory buffer (used for allocating blob and TeeCtx data). */
} MessageHeader;

#define MESSAGE_HEADER_SIZE             (sizeof(DRM_DWORD) * 6)
#define MESSAGE_HEADER_MARKER_OFFSET    (sizeof(DRM_DWORD) * 0)
#define MESSAGE_HEADER_VERSION_OFFSET   (sizeof(DRM_DWORD) * 1)
#define MESSAGE_HEADER_METHODID_OFFSET  (sizeof(DRM_DWORD) * 2)
#define MESSAGE_HEADER_RESULT_OFFSET    (sizeof(DRM_DWORD) * 3)
#define MESSAGE_HEADER_CPARAMS_OFFSET   (sizeof(DRM_DWORD) * 4)
#define MESSAGE_HEADER_IBFREE_OFFSET    (sizeof(DRM_DWORD) * 5)

typedef struct __Parameter
{
    DRM_DWORD  dwParamType;    /* The type of parameter used.                          */
    DRM_DWORD  dwParamIdx;     /* The index of the parameter in the PRITE method call. */
    union
    {
        DRM_DWORD  dwValue;
        DRM_UINT64 qwValue;
        DRM_ID     idValue;

        struct __tagTeeCtx
        {
            DRM_DWORD cbData;
            DRM_DWORD ibData;
        } oTeeCtx;

        struct __tagBlobData
        {
            DRM_DWORD dwType;
            DRM_DWORD dwSubType;
            DRM_DWORD cbData;
            DRM_DWORD ibData;
        } oBlob;

        struct __tagDwordList
        {
            DRM_DWORD cdwData;
            DRM_DWORD ibData;
            DRM_DWORD dwFlags;
        } oDwordList;

        struct __tagQwordList
        {
            DRM_DWORD cqwData;
            DRM_DWORD ibData;
            DRM_DWORD dwFlags;
        } oQwordList;
    } oData;
} Parameter;

#define PARAMETER_SIZE                  (sizeof(DRM_DWORD) * 6)
#define PARAMETER_PARAMTYPE_OFFSET      (sizeof(DRM_DWORD) * 0)
#define PARAMETER_PARAMIDX_OFFSET       (sizeof(DRM_DWORD) * 1)
#define PARAMETER_DWORD_OFFSET          (sizeof(DRM_DWORD) * 2)
#define PARAMETER_QWORD_OFFSET          (sizeof(DRM_DWORD) * 2)
#define PARAMETER_ID_OFFSET             (sizeof(DRM_DWORD) * 2)
#define PARAMETER_CTX_CB_OFFSET         (sizeof(DRM_DWORD) * 2)
#define PARAMETER_CTX_IB_OFFSET         (sizeof(DRM_DWORD) * 3)
#define PARAMETER_BLOB_TYPE_OFFSET      (sizeof(DRM_DWORD) * 2)
#define PARAMETER_BLOB_SUBTYPE_OFFSET   (sizeof(DRM_DWORD) * 3)
#define PARAMETER_BLOB_CB_OFFSET        (sizeof(DRM_DWORD) * 4)
#define PARAMETER_BLOB_IB_OFFSET        (sizeof(DRM_DWORD) * 5)
#define PARAMETER_DWORDLIST_CDW_OFFSET  (sizeof(DRM_DWORD) * 2)
#define PARAMETER_DWORDLIST_IB_OFFSET   (sizeof(DRM_DWORD) * 3)
#define PARAMETER_DWORDLIST_FLAG_OFFSET (sizeof(DRM_DWORD) * 4)
#define PARAMETER_QWORDLIST_CQW_OFFSET  (sizeof(DRM_DWORD) * 2)
#define PARAMETER_QWORDLIST_IB_OFFSET   (sizeof(DRM_DWORD) * 3)
#define PARAMETER_QWORDLIST_FLAG_OFFSET (sizeof(DRM_DWORD) * 4)

typedef struct __tagMessage
{
    MessageHeader header;
    DRM_DWORD     cParams;
    Parameter    *pParams;
    DRM_DWORD     cbMessage;
    DRM_BYTE     *pbMessage;
} Message;

#define UINT32_MAXSIZE 0xFFFFFFFF

#endif /* __PRITEE_UMD_H__ */

