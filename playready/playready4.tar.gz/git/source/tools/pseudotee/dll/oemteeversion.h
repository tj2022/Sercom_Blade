/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef _OEMTEEVERSION_H_
#define _OEMTEEVERSION_H_

ENTER_PK_NAMESPACE;

/* ..\oemteeversion.c requires an oemteeversion.h in order to conditionally support sample protection
** (via #define SUPPORTS_SAMPLE_PROTECTION).  This TEE does not support sample protection, but the header
** is still required.  Thus, this header is an empty placeholder.
**/

EXIT_PK_NAMESPACE;

#endif /* _OEMTEEVERSION_H_ */
