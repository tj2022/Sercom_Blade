/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMCDMIIMPL_H__
#define __DRMCDMIIMPL_H__

#include <drmcdmitypes.h>
#include <drmmodulesupport.h>

ENTER_PK_NAMESPACE;

typedef DRM_VOID( DRM_CALL* DRM_CDMIIMPL_PfnTrace )(
    __in_opt const DRM_DWORD        *f_pdwPROCount,
    __in_opt const DRM_CONST_STRING *f_dstrdrmidKidAdded );

/*
** Helper methods
*/
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_CDMIIMPL_ParseInitDataKeyIdsJson(
    __in                                          DRM_DWORD       f_cbInitData,
    __in_ecount( f_cbInitData )             const DRM_BYTE       *f_pbInitData,
    __out                                         DRM_DWORD      *f_pcbPRO,
    __deref_out_ecount( *f_pcbPRO )               DRM_BYTE      **f_ppbPRO );

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_CDMIIMPL_GetPROFromCencInitData(
    __in                                          DRM_DWORD       f_cbInitData,
    __in_bcount( f_cbInitData )             const DRM_BYTE       *f_pbInitData,
    __out                                         DRM_DWORD      *f_pibPRO,
    __out                                         DRM_DWORD      *f_pcbPRO );

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_CDMIIMPL_MergePROsFromInitData(
    __in                                          DRM_BOOL                f_fPermissive,
    __in                                          DRM_CDMIIMPL_PfnTrace   f_pfnTrace,
    __in                                          DRM_DWORD               f_cbContentInitData,
    __in_bcount( f_cbContentInitData )      const DRM_BYTE               *f_pbContentInitData,
    __out                                         DRM_DWORD              *f_pcbMergedPRO,
    __deref_out_bcount( *f_pcbMergedPRO )         DRM_BYTE              **f_ppbMergedPRO );

EXIT_PK_NAMESPACE;

#endif /*__DRMCDMIIMPL_H__ */

