/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRM_WINDOWS_ENV_H__
#define __DRM_WINDOWS_ENV_H__

#include <drmcompiler.h>
#include <drmsal.h>

/*
# Abstract:
#
# This file contains compiler directives for disabling certain Windows CE
# compiler-time warnings and allow the PK environment to be compiled under
# elevated warning level
#
*/

#if defined (DRM_MSC_VER)

PREFAST_PUSH_IGNORE_WARNINGS_IN_NON_PLAYREADY_HEADERS
#include <windows.h>
#include <mfapi.h>
PREFAST_POP_IGNORE_WARNINGS_IN_NON_PLAYREADY_HEADERS

#ifndef ChkWR
#define ChkWR(expr) {                                           \
            if (!(expr))                                        \
            {                                                   \
                dr = (HRESULT)GetLastError();                   \
                dr = HRESULT_FROM_WIN32((unsigned long)dr);     \
                ExamineDRValue(dr, __FILE__, __LINE__, #expr);  \
                goto ErrorExit;                                 \
            }                                                   \
        }
#endif

#define PRLoadLibraryA(dllpath,h) DRM_DO { h = LoadLibraryA(dllpath); } DRM_WHILE_FALSE

#endif /* DRM_MSC_VER */

#endif /* __DRM_WINDOWS_ENV_H__ */




