/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMLEGACYXMLCERTREVOCATION_H__
#define __DRMLEGACYXMLCERTREVOCATION_H__

#include <oemrsa.h>
#include <drmmanager.h>
#include <drmmodulesupport.h>

ENTER_PK_NAMESPACE;

PREFAST_PUSH_DISABLE_EXPLAINED(__WARNING_NONCONST_BUFFER_PARAM_25033, "Out params can't be const")
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RVK_GetLegacyXMLCertRevocationEntries(
    __inout_bcount( f_cbRevocationData )   DRM_BYTE                 *f_pbRevocationData,
    __in                                   DRM_DWORD                 f_cbRevocationData,
    __out_ecount(1)                        DRM_DWORD                *f_pcEntries,
    __deref_out_ecount_opt( *f_pcEntries ) LEGACYXMLCERT_CRL_ENTRY **f_ppEntries ) DRM_NO_INLINE_ATTRIBUTE;
PREFAST_POP /* __WARNING_NONCONST_BUFFER_PARAM_25033 */

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RVK_VerifyRevocationList(
    __in     const DRM_GUID                    *f_pguidRevocationType,
    __in_opt       DRM_REVOCATIONSTORE_CONTEXT *f_pContextRev,
    __in_opt       DRM_CRYPTO_CONTEXT          *f_pcontextCRYP,
    __in     const DRM_CONST_STRING            *f_pdstrList,
    __out          DRM_DWORD                   *f_pidSerial ) DRM_NO_INLINE_ATTRIBUTE;

DRM_API DRM_RESULT DRM_CALL DRM_RVK_GetLegacyXMLCertList(
    __in_opt                                       DRM_CRYPTO_CONTEXT           *f_pcontextCRYP,
    __in                                           DRM_REVOCATIONSTORE_CONTEXT  *f_pContextRev,
    __in_bcount_opt( *f_pcbRevocationData )  const DRM_BYTE                     *f_pbRevocationData,
    __inout                                        DRM_DWORD                    *f_pcbRevocationData,
    __out                                          DRM_DWORD                    *f_pidSerial ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_RESULT DRM_RVK_UpdateLegacyXMLCertRevocationListDecoded(
    __in                                     DRM_CRYPTO_CONTEXT          *f_pcontextCrypto,
    __in                                     DRM_REVOCATIONSTORE_CONTEXT *f_pContextRev,
    __in_ecount(f_cbRevocationList)    const DRM_BYTE                    *f_pbRevocationList,
    __in                                     DRM_DWORD                    f_cbRevocationList,
    __in_ecount(f_cbRevocationBuffer)  const DRM_BYTE                    *f_pbRevocationBuffer,
    __in                                     DRM_DWORD                    f_cbRevocationBuffer,
    __out_opt                                DRM_BOOL                    *f_pfUpdated,
    __out_opt                                DRM_DWORD                   *f_pdwVersion );

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_RVK_VerifyLegacyXMLCertCRLSignature(
    __inout_opt                          DRM_SECURECORE_CONTEXT *f_pSecureCoreCtx,
    __in_opt                             DRM_SECSTORE_CONTEXT   *f_pcontextSST,
    __in_opt                             DRM_DST                *f_pDatastore,
    __in_bcount( f_cbSignedBytes ) const DRM_BYTE               *f_pbSignedBytes,
    __in                                 DRM_DWORD               f_cbSignedBytes,
    __in_bcount( f_cbSignature )   const DRM_BYTE               *f_pbSignature,
    __in                                 DRM_DWORD               f_cbSignature,
    __in                                 DRM_SUBSTRING           f_dasstrCertificate,
    __in_opt                             DRM_CRYPTO_CONTEXT     *f_pCryptoCtx ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

#endif /*__DRMLEGACYXMLCERTREVOCATION_H__ */

