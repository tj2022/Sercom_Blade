/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMANTIROLLBACKCLOCKCONSTANTS_H__
#define __DRMANTIROLLBACKCLOCKCONSTANTS_H__

#include <drmtypes.h>

ENTER_PK_NAMESPACE;

    extern DRM_GLOBAL_CONST  DRM_CONST_STRING       g_dstrDRM_LS_OLDSAVETIME_ATTR;

EXIT_PK_NAMESPACE;

#endif /* __DRMANTIROLLBACKCLOCKCONSTANTS_H__ */

