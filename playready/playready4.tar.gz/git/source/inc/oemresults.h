/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __OEMRESULTS_H__
#define __OEMRESULTS_H__

/*
** This file is provided for you to add your own error codes which you
** can then return from your OEM functions.
**
** This file is included in drmresults.h where common error codes
** for the PlayReady PK are defined.
**
** The error code range 0x8004DC80 to 0x8004DDFF is reserved for
** your OEM-defined error codes.  Make sure to define your error
** codes within this range to ensure that they are handled properly
** both by the PlayReady PK and by higher-level components in the stack.
**
** This range is large enough to provide you with more than 380 unique
** error codes.  Microsoft recommends that you use a unique error code
** for every location where you use your own error code (except where
** you are intentionally hiding information from hostile actors).
**
** Doing so will lower your troubleshooting and customer support costs
** by enabling you to precisely pinpoint where an error is coming from.
**
** Here are examples of defining your own codes.
** Again, note that they are in the range 0x8004DC80 to 0x8004DDFF.
**
** #define OEM_E_MY_FIRST_ERROR   ((DRM_RESULT)0x8004DC80L)
** #define OEM_E_MY_SECOND_ERROR  ((DRM_RESULT)0x8004DC81L)
** ...
** #define OEM_E_MY_LAST_ERROR    ((DRM_RESULT)0x8004DDFFL)
*/

/*
** Reminder: do not define error codes outside the range
** OEM_E_MINIMUM_ERROR_CODE to OEM_E_MAXIMUM_ERROR_CODE
*/
#define OEM_E_MINIMUM_ERROR_CODE  ((DRM_RESULT)0x8004DC80L)
#define OEM_E_MAXIMUM_ERROR_CODE  ((DRM_RESULT)0x8004DDFFL)


#endif   /* __OEMRESULTS_H__ */

