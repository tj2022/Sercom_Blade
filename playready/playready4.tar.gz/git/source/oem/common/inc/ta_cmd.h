#ifndef TA_CMD_H
#define TA_CMD_H

#include "tee_client_api.h"

#define TA_PLAYREADY_UUID { 0x971dcd80, 0x3f04, 0x11e5, \
		{ 0x9f, 0x3c, 0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b} }  

extern TEEC_Context gTeec_ctx;
extern TEEC_Session gTeec_sess;
extern TEEC_UUID gTeec_uuid;

typedef enum 
{
	TEE_DO_INIT_CMD,
	TEE_DO_CPY,
	TEE_DRM_TEE_STUB_HandleMethodRequest,
	TEE_DRM_TEE_STUB_HandleStructuredMethodRequest,
	TEE_DRM_TEE_STUB_HandleFileOpen,
	TEE_DRM_TEE_STUB_HandleFileDelete,
	TEE_DRM_TEE_STUB_HandleFileClose,
	TEE_DRM_TEE_STUB_HandleFileRead,
	TEE_DRM_TEE_STUB_HandleFileWrite,
	TEE_DRM_TEE_STUB_HandleFileSetFilePointer,
	TEE_DRM_TEE_STUB_HandleFileGetSize,
} ta_cmd_e;


#endif //TA_CMD_H
