/*
*******************************************************************************
**
** Realtek PlayReady REE Part
** Copyright Realtek Semiconductor Corporation. All rights reserved.
**
*******************************************************************************
*/

#ifndef __RTPRD_REE_COMMON_H__
#define __RTPRD_REE_COMMON_H__

/*
*******************************************************************************
** Include
*******************************************************************************
*/
#include <oemcommon.h>
#include <oemteetypes.h>

ENTER_PK_NAMESPACE;
/*
*******************************************************************************
** Define
*******************************************************************************
*/
#ifdef BUILD_PRITEE_TEST
#define RTPRD_REE_BUILD_PRITEE_TEST
#endif
#ifdef USE_VIRTUAL_ADDR
#define RTPRD_REE_USE_VIRTUAL_ADDR
#endif
#ifdef RESET_HDS
#define RTPRD_REE_RESET_HDS
#endif

// support Anti-rollback Clock
#define RTPRD_REE_USE_ANTIROLLBACK_CLOCK_TA

#define RTPRD_REE_RGBSECSTOREPASSWORD \
{\
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',\
    'M', 'O', 'D', 'E', 'L', 'U', 'N', 'I', 'Q', 'U'\
}

/* /tmp/factory/ */
#define RTPRD_REE_RGWCHDRMPATH  DRM_ONE_WCHAR('/', '\0'), DRM_ONE_WCHAR('t', '\0'), DRM_ONE_WCHAR('m', '\0'), \
                                DRM_ONE_WCHAR('p', '\0'), DRM_ONE_WCHAR('/', '\0'), DRM_ONE_WCHAR('f', '\0'), \
                                DRM_ONE_WCHAR('a', '\0'), DRM_ONE_WCHAR('c', '\0'), DRM_ONE_WCHAR('t', '\0'), \
                                DRM_ONE_WCHAR('o', '\0'), DRM_ONE_WCHAR('r', '\0'), DRM_ONE_WCHAR('y', '\0'), \
                                DRM_ONE_WCHAR('/', '\0'), DRM_ONE_WCHAR('\0', '\0')

#define RTPRD_REE_FUNCIN do {\
        /*Oem_Debug_Trace("%s -- IN\n",__FUNCTION__);*/\
    } while(FALSE);

/*
******************************************************************************
** REE Part API
*******************************************************************************
*/

/******************************************************************************
** for oemteeproxyrealinit.c
******************************************************************************/
/*
*******************************************************************************
** Name: RTPRD_REE_Initialize
** Description: open session and do init
*******************************************************************************
*/
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL RTPRD_REE_Initialize( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_Uninitialize
** Description: close session
*******************************************************************************
*/
DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL RTPRD_REE_Uninitialize( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;



/******************************************************************************
** for oemteeproxyreal.c
******************************************************************************/
/*
*******************************************************************************
** Name: RTPRD_REE_MethodInvoke
** Description: transfers the provided request message from the normal world
**              to the secure world.
*******************************************************************************
*/
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL RTPRD_REE_MethodInvoke(
    __in_opt                                DRM_VOID                    *f_pvUserCtx,
    __in                                    DRM_DWORD                    f_dwFunctionMapOEMValue,
    __in                                    DRM_DWORD                    f_cbRequestMessage,
    __inout_bcount( f_cbRequestMessage )    DRM_BYTE                    *f_pbRequestMessage,
    __inout_opt                             DRM_DWORD                   *f_pcbResponseMessage,
    __inout_bcount_part_opt( *f_pcbResponseMessage, *f_pcbResponseMessage )
                                            DRM_BYTE                    *f_pbResponseMessage )  DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: OEM_TEE_PROXY_StructuredMethodInvoke
** Description: transfers the provided request message from the normal world
**              to the secure world.
                With special defined struct, contain src address(VA) and dst address(PA)
*******************************************************************************
*/
DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL RTPRD_REE_StructuredMethodInvoke(
    __in_opt                                DRM_VOID                    *f_pvUserCtx,
    __in                                    DRM_DWORD                    f_dwFunctionMapOEMValue,
    __in                                    DRM_DWORD                    f_cbRequestMessage,
    __inout_bcount( f_cbRequestMessage )    DRM_BYTE                    *f_pbRequestMessage,
    __in                                    DRM_DWORD                    f_pbEncryptedContent,
    __in                                    DRM_DWORD                    f_cbEncryptedContent,
    __in                                    DRM_DWORD                    f_pbDst,
    __in                                    DRM_DWORD                    f_cbDst,
    __inout_opt                             DRM_DWORD                   *f_pcbResponseMessage,
    __inout_bcount_part_opt( *f_pcbResponseMessage, *f_pcbResponseMessage )
                                            DRM_BYTE                    *f_pbResponseMessage ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileOpen
** Description: open file in RPMB
*******************************************************************************
*/
DRM_API OEM_FILEHDL DRM_CALL RTPRD_REE_FileOpen(
    __in_opt   DRM_VOID    *f_pOEMContext,
    __in_z const DRM_WCHAR *f_pwszFileName,
    __in       DRM_DWORD    f_dwAccessMode,
    __in       DRM_DWORD    f_dwShareMode,
    __in       DRM_DWORD    f_dwCreationDisposition,
    __in       DRM_DWORD    f_dwAttributes ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileDelete
** Description: delete file in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileDelete(
    __in_z const DRM_WCHAR *f_pwszFileName ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileClose
** Description: close file in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileClose(
    __in OEM_FILEHDL f_hFile) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileRead
** Description: read file in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileRead(
    __in_opt OEM_FILEHDL                                                         f_hFile,
    __out_ecount_part( f_nNumberOfBytesToRead, *f_pNumberOfBytesRead ) DRM_VOID *f_pBuffer,
    __in DRM_DWORD                                                               f_nNumberOfBytesToRead,
    __out DRM_DWORD                                                             *f_pNumberOfBytesRead) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileWrite
** Description: write file in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileWrite(
    __in OEM_FILEHDL                                 f_hFile,
    __in_ecount( f_nNumberOfBytesToWrite ) DRM_VOID *f_pBuffer,
    __in DRM_DWORD                                   f_nNumberOfBytesToWrite,
    __out DRM_DWORD                                 *f_pNumberOfBytesWritten ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileSetFilePointer
** Description: set file pointer in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileSetFilePointer(
    __in OEM_FILEHDL     f_hFile,
    __in DRM_LONG        f_lDistanceToMove,
    __in DRM_DWORD       f_dwMoveMethod,
    __out_opt DRM_DWORD *f_pdwNewFilePointer) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_FileGetSize
** Description: get file size in RPMB
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_FileGetSize(
    __in OEM_FILEHDL  f_hFile,
    __out DRM_DWORD  *f_pcbFile) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_DoCpy
** Description: copy data from Src VA to  Dst PA
*******************************************************************************
*/
DRM_API DRM_RESULT DRM_CALL RTPRD_REE_DoCpy(
    __in DRM_BYTE *Src,
    __in DRM_BYTE *Dst,
    __in DRM_DWORD Size) DRM_NO_INLINE_ATTRIBUTE;



/******************************************************************************
** for oemdebug.c
******************************************************************************/
/*
*******************************************************************************
** Name: RTPRD_REE_DebugForAndroid
** Description: add debug tag and log for android
*******************************************************************************
*/
DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL RTPRD_REE_DebugForAndroid(
    __in const DRM_CHAR     *rgchBuffer ) DRM_NO_INLINE_ATTRIBUTE;



/******************************************************************************
** for oemfileio.c
******************************************************************************/
/*
*******************************************************************************
** Name: RTPRD_REE_IsNot_HDS_Path
** Description: check dst is HDS path or not
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_IsNot_HDSPath(
    __in const DRM_CHAR     *dst ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_IsNot_HDSFile
** Description: check File is HDS file or not
*******************************************************************************
*/
DRM_API DRM_BOOL DRM_CALL RTPRD_REE_IsNot_HDSFile(
    __in OEM_FILEHDL        f_hFile ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_Set_HDSFileHandle
** Description: set local static HDS handler parameter
*******************************************************************************
*/
DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL RTPRD_REE_Set_HDSFileHandle(
    __in OEM_FILEHDL        f_hFile ) DRM_NO_INLINE_ATTRIBUTE;
/*
*******************************************************************************
** Name: RTPRD_REE_Clear_HDSFileHandle
** Description: clear local static HDS handler parameter
*******************************************************************************
*/
DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL RTPRD_REE_Clear_HDSFileHandle( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;



/******************************************************************************
** for oemtime.c
******************************************************************************/
/*
*******************************************************************************
** Name: RTPRD_REE_GetAntirollbackTime
** Description: use antirollback TA to get DRM time
*******************************************************************************
*/
#ifdef RTPRD_REE_USE_ANTIROLLBACK_CLOCK_TA
DRM_API time_t DRM_CALL RTPRD_REE_GetAntirollbackTime( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;
#endif
/*
*******************************************************************************
** Name: RTPRD_REE_Set_TimeOfDay
** Description: just call SetTimeOfDay
*******************************************************************************
*/
DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL RTPRD_REE_Set_TimeOfDay( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;


EXIT_PK_NAMESPACE;
#endif /*  __RTPRD_REE_COMMON_H__ */

