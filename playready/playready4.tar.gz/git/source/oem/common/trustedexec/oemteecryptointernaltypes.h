/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef _OEMTEECRYPTOINTERNALTYPES_H_
#define _OEMTEECRYPTOINTERNALTYPES_H_ 1

#include <oemteetypes.h>
#include <oembroker.h>

ENTER_PK_NAMESPACE;

typedef struct __tagOEM_TEE_KEY_ECC
{
    PRIVKEY_P256         oPriv;
} OEM_TEE_KEY_ECC;

typedef struct __tagOEM_TEE_KEY_AES
{
    DRM_BYTE             rgbRawKey[DRM_AES_KEYSIZE_128];
    DRM_AES_KEY          oKey;
} OEM_TEE_KEY_AES;

#define OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_AES128_TO_DRM_BYTES( _pKey )    ( DRM_REINTERPRET_CAST( OEM_TEE_KEY_AES, (_pKey)->pKey )->rgbRawKey)
#define OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_AES128_TO_DRM_AES_KEY( _pKey )  (&DRM_REINTERPRET_CAST( OEM_TEE_KEY_AES, (_pKey)->pKey )->oKey)
#define OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_ECC256_TO_PRIVKEY_P256( _pKey ) (&DRM_REINTERPRET_CAST( OEM_TEE_KEY_ECC, (_pKey)->pKey )->oPriv)
#define OEM_TEE_INTERNAL_CONVERT_ECC256_PRIVKEY_P256_TO_OEM_TEE_KEY( _pKey ) (&DRM_REINTERPRET_CAST( OEM_TEE_KEY, (_pKey)->m_rgbPrivkey )->pKey)

#define OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_AES128_TO_BROKER( _pKey )  \
    ( Oem_Broker_IsTEE() ? (DRM_REINTERPRET_CAST(DRM_AES_KEY, (OEM_TEE_KEY *)(_pKey))) : OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_AES128_TO_DRM_AES_KEY((OEM_TEE_KEY *)(_pKey)) )

#define OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_ECC256_TO_BROKER( _pKey )  \
    ( Oem_Broker_IsTEE() ? DRM_REINTERPRET_CAST(PRIVKEY_P256, (_pKey)) : OEM_TEE_INTERNAL_CONVERT_OEM_TEE_KEY_ECC256_TO_PRIVKEY_P256((OEM_TEE_KEY *)(_pKey)) )


EXIT_PK_NAMESPACE;

#endif /* _OEMTEECRYPTOINTERNALTYPES_H_ */

