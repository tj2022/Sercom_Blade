/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMTEERPROV_H__
#define __DRMTEERPROV_H__ 1

#include <oemtee.h>

ENTER_PK_NAMESPACE;

typedef enum
{
    DRM_PROVISIONING_REQ_TYPE_KEYS_ON_CLIENT = 1,
    DRM_PROVISIONING_REQ_TYPE_KEYS_ON_SERVER = 2,
    DRM_PROVISIONING_REQ_TYPE_KEYS_ON_SERVER_PROTECTED_TYPE_1 = 3,
} DRM_PROVISIONING_REQ_TYPES;


typedef enum
{
    DRM_PROVISIONING_CONF_ENCRYPTION_TYPES_AESCBC = 1,
    DRM_PROVISIONING_CONF_ENCRYPTION_TYPES_NONE = 2,
} DRM_PROVISIONING_CONF_ENCRYPTION_TYPES;

typedef enum
{
    DRM_PROVISIONING_SIGNATURE_TYPE_AES_128_CMAC = 1
} DRM_PROVISIONING_CONF_SIGNATURE_TYPES;

typedef enum
{
    DRM_PROVISIONING_ENCRYPTION_TYPE_AES_128_KEY_WRAP = 1,
} DRM_PROVISIONING_KEY_ENCRYPTION_TYPE;


/* AES CBC encrypt of 16 bytes maps to 48 bytes with padding. */
typedef struct __tagDRM_PROVISIONING_ConfBlob48
{
    DRM_BYTE rgbConfBlob48[DRM_AES_BLOCKLEN * 3];
} DRM_PROVISIONING_CONFBLOB48;

typedef enum __tagDRM_PROVISIONING_MODEL_AUTHORIZATION_SIGNATURE_TYPES
{
    DRM_PROVISIONING_MODEL_AUTHORIZATION_SIGNATURE_TYPE_ECDSA_P256_OVER_32_BYTES = 1,
} DRM_PROVISIONING_MODEL_AUTHORIZATION_SIGNATURE_TYPES;

typedef enum
{
    Derive_K_Conf = 0,
    Derive_K_Wrap = 1,
    Derive_K_Sign = 2
} ProvisioningKeyType;

#define RPROV_REQUEST_TYPE_GENERIC          1
#define RPROV_REQUEST_TYPE_OEM_SPECIFIC_1   2
#define RPROV_REQUEST_TYPE_OEM_SPECIFIC_99  99

#define ALLOWED_TIMESTAMP_DIFFERENCE (60u*5u*DRM_C_TICS_PER_SECOND) /* 5 minutes */

EXIT_PK_NAMESPACE;

#endif /* __DRMTEERPROV_H__ */