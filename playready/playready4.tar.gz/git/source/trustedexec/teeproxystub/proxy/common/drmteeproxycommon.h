/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef __DRMTEEPROXYCOMMON_H__
#define __DRMTEEPROXYCOMMON_H__ 1

#include <drmteetypes.h>
#include <drmteeproxystubcommon.h>
#include <drmxbbuilder.h>
#include <drmteeproxyformat_generated.h>

ENTER_PK_NAMESPACE;

/* Normal world TEE proxy helper functions */

DRM_NO_INLINE DRM_API DRM_DWORD DRM_CALL DRM_TEE_PROXY_GetFunctionMapOEMValueFromList(
    __in                                  const DRM_TEE_DWORDLIST              *f_pFunctionMap,
    __in                                        DRM_METHOD_ID_DRM_TEE           f_eFunctionID ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_GetFunctionMapOEMValue(
     __in                                 const DRM_TEE_PROXY_CONTEXT           *f_pTEEContext,
     __in                                       DRM_METHOD_ID_DRM_TEE            f_eMethodID,
     __out                                      DRM_DWORD                       *f_pdwFunctionMapOEMValue ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_XB_AddEntryTEEContext(
    __inout                                     DRM_XB_BUILDER_CONTEXT          *f_pXBContext,
    __in                                        DRM_WORD                         f_wXBType,
    __in                                        DRM_TEE_PROXY_CONTEXT           *f_pTEEContext,
    __inout                                     XB_DRM_TEE_CONTEXT              *f_pXBTEEContext ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_XB_TEECtxFromXBTEECtx(
    __in                                  const XB_DRM_TEE_CONTEXT              *f_pXBTEECtx,
    __inout                                     DRM_TEE_PROXY_CONTEXT           *f_pTEECtx ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_GetDwordListParamByIndex(
    __in_opt                                    DRM_TEE_PROXY_CONTEXT           *f_pTeeCtx,
    __in                                  const XB_DRM_TEE_PROXY_METHOD_REQ     *f_pXBMethodReq,
    __in                                        DRM_DWORD                        f_dwParamIndex,
    __in                                        DRM_BOOL                         f_fCopy,
    __inout                                     DRM_TEE_DWORDLIST               *f_pDwordList ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_GetQwordListParamByIndex(
    __in_opt                                    DRM_TEE_PROXY_CONTEXT           *f_pTeeCtx,
    __in                                  const XB_DRM_TEE_PROXY_METHOD_REQ     *f_pXBMethodReq,
    __in                                        DRM_DWORD                        f_dwParamIndex,
    __in                                        DRM_BOOL                         f_fCopy,
    __inout                                     DRM_TEE_QWORDLIST               *f_pQwordList ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_GetBlobParamByIndex(
    __in_opt                                    DRM_TEE_PROXY_CONTEXT           *f_pTeeCtx,
    __in                                  const XB_DRM_TEE_PROXY_METHOD_REQ     *f_pXBMethodReq,
    __in                                        DRM_DWORD                        f_dwParamIndex,
    __in                                        DRM_BOOL                         f_fCopyBlob,
    __out                                       DRM_TEE_BYTE_BLOB               *f_pBlob ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_PreInvokeMethod(
    __in_opt                            const DRM_TEE_PROXY_SERIALIZATION_REQUIREMENTS    *f_pSerializationRequirements,
    __inout                             const DRM_XB_BUILDER_CONTEXT                      *f_pXBContext,
    __in                                      DRM_DWORD                                    f_dwFunctionMapOEMValue,
    __in                                      DRM_METHOD_ID_DRM_TEE                        f_eMethodID,
    __out                                     DRM_TEE_BYTE_BLOB                           *f_pReqMsg,
    __in_opt                            const DRM_DWORD                                   *f_pcbRespMsg ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_PostInvokeMethod(
    __in_opt                            const DRM_TEE_PROXY_SERIALIZATION_REQUIREMENTS   *f_pSerializationRequirements,
    __in                                      DRM_METHOD_ID_DRM_TEE                       f_eMethodID,
    __out                                     XB_DRM_TEE_PROXY_METHOD_REQ                *f_pProxyMethodResp,
    __in_opt                            const DRM_DWORD                                  *f_pcbRespMsg,
    __in_bcount_opt( *f_pcbRespMsg )    const DRM_BYTE                                   *f_pbRespMsg,
    __out                                     DRM_DWORD                                  *f_pcbRespStack,
    __deref_out_bcount_opt( *f_pcbRespStack ) DRM_BYTE                                  **f_ppbRespStack,
    __out                                     DRM_RESULT                                 *f_pdrInvokeResult ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_InvokeMethod(
    __inout                                         DRM_TEE_PROXY_CONTEXT           *f_pTeeContext,
    __in                                      const DRM_XB_BUILDER_CONTEXT          *f_pXBContext,
    __in                                            DRM_DWORD                        f_dwFunctionMapOEMValue,
    __in                                            DRM_METHOD_ID_DRM_TEE            f_eMethodID,
    __out                                           XB_DRM_TEE_PROXY_METHOD_REQ     *f_pProxyMethodResp,
    __inout_opt                                     DRM_DWORD                       *f_pcbRespMsg,
    __inout_bcount_opt( *f_pcbRespMsg )             DRM_BYTE                        *f_pbRespMsg,
    __out                                           DRM_DWORD                       *f_pcbRespStack,
    __deref_out_bcount_opt( *f_pcbRespStack )       DRM_BYTE                       **f_ppbRespStack,
    __out                                           DRM_RESULT                      *f_pdrInvokeResult ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_PROXY_GetMaxResponseMessageSize(
    __in                                  const DRM_TEE_PROXY_CONTEXT          *f_pTeeCtx,
    __in                                        DRM_DWORD                       f_dwMethodID,
    __inout_ecount( 1 )                         DRM_DWORD                      *f_pcbEstimatedResponseSize ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

#endif /* __DRMTEEPROXYCOMMON_H__ */
