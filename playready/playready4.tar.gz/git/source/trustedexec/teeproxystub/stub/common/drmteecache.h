/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#ifndef _DRMTEECACHE_H_
#define _DRMTEECACHE_H_ 1

#include <drmteetypes.h>
#include <oemsha256types.h>
#include <oemeccp256.h>

ENTER_PK_NAMESPACE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_Initialize( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_AddContext(
    __in            const DRM_TEE_CONTEXT              *f_pContext ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_ReferenceContext(
    __in            const DRM_TEE_CONTEXT              *f_pContext ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_RemoveContext(
    __in            const DRM_TEE_CONTEXT              *f_pContext ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_CheckHash(
    __in            const OEM_SHA256_DIGEST            *f_pHash,
    __out                 DRM_BOOL                     *f_pfHashFound ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_TEE_IMPL_CACHE_AddHash(
    __in            const OEM_SHA256_DIGEST            *f_pHash ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL DRM_TEE_IMPL_CACHE_Clear( DRM_VOID ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

#endif /* _DRMTEECACHE_H_ */

