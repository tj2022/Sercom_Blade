/**@@@+++@@@@******************************************************************
**
** Microsoft (r) PlayReady (r)
** Copyright (c) Microsoft Corporation. All rights reserved.
**
***@@@---@@@@******************************************************************
*/

#include <drmh264.h>

ENTER_PK_NAMESPACE;

/*
** If this is set to 1, the structures defined here have their members sequenced
**  in the same order as the original content file per the H.264 spec.
** If this is set to 0, the structures defined here have their members UNsequenced
**  in an attempt to minimize the number of padding bytes used in each one.
** The default is 0, but setting it to 1 may occasionally be useful for debugging
**  purposes, and the sequenced structure declarations also have comments which
**  can assist with mapping their members back to spec.
**  (Such comments would have no meaning for the unsequenced structures.)
*/
#define DRM_H264_USE_SEQUENCED_STRUCTURES           0

/*
** Note: Structure definitions in this file have the following properties.
** 1. They are self-contained (i.e. have no pointers).
**    They can therefore be serialized/deserialized to/from binary with a straight memcpy.
**    They can therefore be binary-compared with a straight memcmp.
** 2. Both the names of the structures and the names of their members match
**    the names used in the original spec (14496-10 MPEG-4 Part 10, H264-AVC).
**    This makes it much easier to compare the function with inofrmation in the spec
**    even though it means they do not conform to the standard PK naming conventions.
** 3. They are tightly packed using small types to minimize the amount of data that has
**    to be passed back from the secure world to the insecure world inside the SPS/PPS dictionary.
**    We also use #pragma pack(1) where available to eliminate unnecessary alignment bytes.
** 4. They do not contain information we will not use for verification.
**    This means they are not complete representations of the data in the H.264 spec.
**    In some cases (but NOT necessarily all), the "not present" data has comments regarding it,
**    but this should NOT be relied upon to be complete.
*/

PRAGMA_PACK_PUSH_VALUE(1)

#define DRM_MAX_NALU_PARSING_SIZE   256

/*
** BEGIN: Nalu Location Definitions
*/
#define DRM_NALU_TYPE_SLICE    1
#define DRM_NALU_TYPE_IDR      5
#define DRM_NALU_TYPE_SEI      6
#define DRM_NALU_TYPE_SPS      7
#define DRM_NALU_TYPE_PPS      8

/*
** A start code has four bytes:
**   A three byte fixed value plus a single variable byte.
**   The single variable byte has:
**      3 bits which represent the reference IDC
**      5 bits which represent the Nalu Type.
*/
#define DRM_START_CODE_SIZE                         ((DRM_DWORD)sizeof(DRM_DWORD))

/* A Nalu could theoretically be just a start code. */
#define DRM_MINIMUM_NALU_SIZE                       DRM_START_CODE_SIZE

/* Used to mask a DWORD down to just 3 bytes. */
#define DRM_THREE_BYTE_MASK                         ((DRM_DWORD)0x00FFFFFF)

/* The emulation prevention byte inside a Nalu has this value */
#define DRM_NALU_EMULATION_PREVENTION               ((DRM_DWORD)0x3)

/* Every Nalu should start with this three byte Nalu (i.e. after masking the first DWORD with DRM_THREE_BYTE_MASK */
#define DRM_NALU_EXPECTED_THREE_BYTE_START_CODE     ((DRM_DWORD)0x00010000)

/* Nalu Type is the 4th byte after the start code */
#define DRM_NALU_TYPE_AFTER_START_CODE_BYTE         ((DRM_DWORD)3)

/* Only the last 5 bits of the byte are the actual Nalu Type */
#define DRM_NALU_TYPE_BYTE_MASK                     ((DRM_DWORD)0x1F)
/*
** END: Nalu Location Definitions
*/

/*
** BEGIN: SPS Definitions
*/
#define DRM_PROFILE_IDC_BASE            66
#define DRM_PROFILE_IDC_MAIN            77
#define DRM_PROFILE_IDC_EXTENDED        88
#define DRM_PROFILE_IDC_FREXT_HP        100      /* !< YUV 4:2:0/8 "High"           */
#define DRM_PROFILE_IDC_FREXT_Hi10P     110      /* !< YUV 4:2:0/10 "High 10"       */
#define DRM_PROFILE_IDC_FREXT_Hi422     122      /* !< YUV 4:2:2/10 "High 4:2:2"    */
#define DRM_PROFILE_IDC_FREXT_Hi444     244      /* !< YUV 4:4:4/12 "High 4:4:4"    */

#define DRM_MAX_SPS  32
#define DRM_MAX_PPS  256

#define DRM_MAX_DPB_SIZE    16

#define DRM_MAX_PICTURE_WIDTH   4096
#define DRM_MAX_PICTURE_HEIGHT  2304
#define DRM_MAX_PICTURE_TO_MAX_MB_FACTOR                    16
#define DRM_MAX_PICTURE_TO_MAX_MB_FACTOR_BIT_SHIFT_RIGHT     4              /* x / 16 == x >> 4 */
#define DRM_MAX_MB_WIDTH        ( DRM_MAX_PICTURE_WIDTH  >> DRM_MAX_PICTURE_TO_MAX_MB_FACTOR_BIT_SHIFT_RIGHT )     /* Note: 4069 >> 4 == 256 MB */
#define DRM_MAX_MB_HEIGHT       ( DRM_MAX_PICTURE_HEIGHT >> DRM_MAX_PICTURE_TO_MAX_MB_FACTOR_BIT_SHIFT_RIGHT )     /* Note: 2304 >> 4 == 144 MB */

#define P_SLICE  0
#define B_SLICE  1
#define I_SLICE  2
#define SP_SLICE 3
#define SI_SLICE 4

extern const DRM_BYTE c_rgiValidValuesFor_profile_idc[7];
extern const DRM_BYTE c_rgiValidValuesFor_level_idc[16];
extern const DRM_BYTE c_rgbScalingListScanValues0to5[16];
extern const DRM_BYTE c_rgbScalingListScanValues6to7[64];
extern const DRM_DWORD c_rgiSubWidthCRatio[4];
extern const DRM_DWORD c_rgiSubHeightCRatio[4];

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_hrd_parameters_t_sequenced
{
    DRM_BYTE    cpb_cnt_minus1;                                 /* ue(v) */
    DRM_BYTE    bit_rate_scale;                                 /* u(4)  */
    DRM_BYTE    cpb_size_scale;                                 /* u(4)  */
    DRM_DWORD   bit_rate_value_minus1[ 32 ];                    /* ue(v) */
    DRM_DWORD   cpb_size_value_minus1[ 32 ];                    /* ue(v) */
    DRM_BYTE    cbr_flag[ 32 ];                                 /* u(1)  */
    DRM_BYTE    initial_cpb_removal_delay_length_minus1;        /* u(5)  */
    DRM_BYTE    cpb_removal_delay_length_minus1;                /* u(5)  */
    DRM_BYTE    dpb_output_delay_length_minus1;                 /* u(5)  */
    DRM_BYTE    time_offset_length;                             /* u(5)  */
} hrd_parameters_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_hrd_parameters_t_unsequenced
{
    DRM_DWORD   bit_rate_value_minus1[ 32 ];
    DRM_DWORD   cpb_size_value_minus1[ 32 ];
    DRM_BYTE    cbr_flag[ 32 ];

    DRM_BYTE    cpb_cnt_minus1;
    DRM_BYTE    bit_rate_scale;
    DRM_BYTE    cpb_size_scale;
    DRM_BYTE    initial_cpb_removal_delay_length_minus1;

    DRM_BYTE    cpb_removal_delay_length_minus1;
    DRM_BYTE    dpb_output_delay_length_minus1;
    DRM_BYTE    time_offset_length;
} hrd_parameters_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_vui_seq_parameters_t_sequenced
{
    DRM_BYTE            aspect_ratio_info_present_flag;                 /* u(1)  */
    DRM_BYTE            aspect_ratio_idc;                               /* u(8)  */
    DRM_WORD            sar_width;                                      /* u(16) */
    DRM_WORD            sar_height;                                     /* u(16) */
    DRM_BYTE            overscan_info_present_flag;                     /* u(1)  */
    DRM_BYTE            overscan_appropriate_flag;                      /* u(1)  */
    DRM_BYTE            video_signal_type_present_flag;                 /* u(1)  */
    DRM_BYTE            video_format;                                   /* u(3)  */
    DRM_BYTE            video_full_range_flag;                          /* u(1)  */
    DRM_BYTE            colour_description_present_flag;                /* u(1)  */
    DRM_BYTE            colour_primaries;                               /* u(8)  */
    DRM_BYTE            transfer_characteristics;                       /* u(8)  */
    DRM_BYTE            matrix_coefficients;                            /* u(8)  */
    DRM_BYTE            chroma_location_info_present_flag;              /* u(1)  */
    DRM_BYTE            chroma_sample_loc_type_top_field;               /* ue(v) */
    DRM_BYTE            chroma_sample_loc_type_bottom_field;            /* ue(v) */
    DRM_BYTE            timing_info_present_flag;                       /* u(1)  */
    DRM_DWORD           num_units_in_tick;                              /* u(32) */
    DRM_DWORD           time_scale;                                     /* u(32) */
    DRM_BYTE            fixed_frame_rate_flag;                          /* u(1)  */
    /*
    ** if( ( nal_hrd_parameters_present_flag
    **  || ( vcl_hrd_parameters_present_flag ) )
    */
    DRM_BYTE            pic_struct_present_flag;                        /* u(1)  */
    DRM_BYTE            bitstream_restriction_flag;                     /* u(1)  */
    DRM_BYTE            motion_vectors_over_pic_boundaries_flag;        /* u(1)  */
    DRM_DWORD           max_bytes_per_pic_denom;                        /* ue(v) */
    DRM_DWORD           max_bits_per_mb_denom;                          /* ue(v) */
    DRM_DWORD           log2_max_mv_length_vertical;                    /* ue(v) */
    DRM_DWORD           log2_max_mv_length_horizontal;                  /* ue(v) */
    DRM_DWORD           num_reorder_frames;                             /* ue(v) */
    DRM_DWORD           max_dec_frame_buffering;                        /* ue(v) */

    DRM_BYTE            low_delay_hrd_flag;                             /* u(1)  */
    DRM_BYTE            nal_hrd_parameters_present_flag;                /* u(1)  */
    DRM_BYTE            vcl_hrd_parameters_present_flag;                /* u(1)  */
    hrd_parameters_t    nal_hrd_parameters;                             /* (sub-struct) */
    hrd_parameters_t    vcl_hrd_parameters;                             /* (sub-struct) */
} vui_seq_parameters_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_vui_seq_parameters_t_unsequenced
{
    DRM_DWORD           num_units_in_tick;
    DRM_DWORD           time_scale;
    DRM_DWORD           max_bytes_per_pic_denom;
    DRM_DWORD           max_bits_per_mb_denom;
    DRM_DWORD           log2_max_mv_length_vertical;
    DRM_DWORD           log2_max_mv_length_horizontal;
    DRM_DWORD           num_reorder_frames;
    DRM_DWORD           max_dec_frame_buffering;

    DRM_WORD            sar_width;
    DRM_WORD            sar_height;

    DRM_BYTE            aspect_ratio_idc;
    DRM_BYTE            video_format;
    DRM_BYTE            colour_primaries;
    DRM_BYTE            transfer_characteristics;

    DRM_BYTE            matrix_coefficients;
    DRM_BYTE            chroma_sample_loc_type_top_field;
    DRM_BYTE            chroma_sample_loc_type_bottom_field;
    DRM_BYTE            aspect_ratio_info_present_flag;

    DRM_BYTE            overscan_info_present_flag;
    DRM_BYTE            overscan_appropriate_flag;
    DRM_BYTE            video_signal_type_present_flag;
    DRM_BYTE            video_full_range_flag;

    DRM_BYTE            colour_description_present_flag;
    DRM_BYTE            chroma_location_info_present_flag;
    DRM_BYTE            timing_info_present_flag;
    DRM_BYTE            fixed_frame_rate_flag;

    DRM_BYTE            pic_struct_present_flag;
    DRM_BYTE            bitstream_restriction_flag;
    DRM_BYTE            motion_vectors_over_pic_boundaries_flag;
    DRM_BYTE            low_delay_hrd_flag;

    DRM_BYTE            nal_hrd_parameters_present_flag;
    DRM_BYTE            vcl_hrd_parameters_present_flag;

    hrd_parameters_t    nal_hrd_parameters;
    hrd_parameters_t    vcl_hrd_parameters;
} vui_seq_parameters_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_seq_parameter_set_rbsp_mini_t_sequenced
{
    DRM_BYTE                fIsSPS;                                         /* (dictionary helper data, MUST be first, always TRUE for this struct) */
    DRM_BYTE                profile_idc;                                    /* u(8) */
    DRM_WORD                seq_parameter_set_id;                           /* ue(v) */
    DRM_BYTE                chroma_format_idc;                              /* ue(v) */
    DRM_BYTE                bit_depth_luma_minus8;                          /* ue(v) */
    DRM_BYTE                log2_max_frame_num_minus4;                      /* ue(v) */
    DRM_BYTE                pic_order_cnt_type;                             /* ue(v) */
    DRM_BYTE                log2_max_pic_order_cnt_lsb_minus4;              /* ue(v) */
    DRM_BYTE                delta_pic_order_always_zero_flag;               /* u(1)  */
    DRM_BYTE                num_ref_frames;                                 /* ue(v) */
    DRM_DWORD               pic_width_in_mbs_minus1;                        /* ue(v) */
    DRM_DWORD               pic_height_in_map_units_minus1;                 /* ue(v) */
    DRM_BYTE                frame_mbs_only_flag;                            /* u(1)  */
} seq_parameter_set_rbsp_mini_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_seq_parameter_set_rbsp_mini_t_unsequenced
{
    DRM_BYTE                fIsSPS;                                         /* (dictionary helper data, MUST be first, always TRUE for this struct) */
    DRM_BYTE                profile_idc;
    DRM_BYTE                chroma_format_idc;
    DRM_BYTE                bit_depth_luma_minus8;

    DRM_DWORD               pic_width_in_mbs_minus1;
    DRM_DWORD               pic_height_in_map_units_minus1;

    DRM_WORD                seq_parameter_set_id;
    DRM_BYTE                log2_max_frame_num_minus4;
    DRM_BYTE                pic_order_cnt_type;

    DRM_BYTE                log2_max_pic_order_cnt_lsb_minus4;
    DRM_BYTE                num_ref_frames;
    DRM_BYTE                delta_pic_order_always_zero_flag;
    DRM_BYTE                frame_mbs_only_flag;
} seq_parameter_set_rbsp_mini_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_seq_parameter_set_rbsp_t_sequenced
{
    seq_parameter_set_rbsp_mini_t   mini;

    /* DRM_BYTE    profile_idc;                                                 */  /* Inside mini: u(8) */

    /*
    ** Note: There are 8 bits here we are ignoring:
    ** any constraint_set*_flags and any reserved_zero_*bits
    ** (which come after constraint_set* and complete the byte).
    ** Our parser doesn't need them for anything.
    */

    DRM_BYTE                level_idc;                                      /* u(8)  */
    /* DRM_WORD                seq_parameter_set_id;                            */  /* Inside mini: ue(v) */
    /* DRM_BYTE                chroma_format_idc;                               */  /* Inside mini: ue(v) */

    DRM_BYTE                residue_transform_flag;                         /* u(1)  */

    /* DRM_BYTE                bit_depth_luma_minus8;                           */  /* Inside mini: ue(v) */
    DRM_BYTE                bit_depth_chroma_minus8;                        /* ue(v) */

    DRM_BYTE                lossless_qpprime_flag;                          /* u(1)  */

    DRM_BYTE                seq_scaling_matrix_present_flag;                /* u(1)  */
    DRM_BYTE                seq_scaling_list_present_flag[8];               /* u(1)  */
    DRM_LONG                ScalingList4x4[6][16];                          /* se(v) */
    DRM_LONG                ScalingList8x8[2][64];                          /* se(v) */
    DRM_BYTE                UseDefaultScalingMatrix4x4Flag[6];              /* (computed) */
    DRM_BYTE                UseDefaultScalingMatrix8x8Flag[2];              /* (computed) */

    /* DRM_BYTE                log2_max_frame_num_minus4;                       */  /* Inside mini: ue(v) */
    /* DRM_BYTE                pic_order_cnt_type;                              */  /* Inside mini: ue(v) */
    /* if( pic_order_cnt_type == 0 ) */
    /* DRM_BYTE                log2_max_pic_order_cnt_lsb_minus4;               */  /* Inside mini: ue(v) */
    /* else if( pic_order_cnt_type == 1 ) */
    /* DRM_BYTE                delta_pic_order_always_zero_flag;                */  /* Inside mini: u(1)  */
    DRM_LONG                offset_for_non_ref_pic;                         /* se(v) */
    DRM_LONG                offset_for_top_to_bottom_field;                 /* se(v) */
    DRM_WORD                num_ref_frames_in_pic_order_cnt_cycle;          /* ue(v) */
    /* for( i = 0; i < num_ref_frames_in_pic_order_cnt_cycle; i++ ) */
    DRM_LONG                offset_for_ref_frame[256];                      /* se(v) */
    /* DRM_BYTE                num_ref_frames;                                  */  /* Inside mini: ue(v) */
    DRM_BYTE                gaps_in_frame_num_value_allowed_flag;           /* u(1)  */
    /* DRM_DWORD               pic_width_in_mbs_minus1;                         */  /* Inside mini: ue(v) */
    /* DRM_DWORD               pic_height_in_map_units_minus1;                  */  /* Inside mini: ue(v) */
    /* DRM_BYTE                frame_mbs_only_flag;                             */  /* Inside mini: u(1)  */
    /* if( !frame_mbs_only_flag ) */
    DRM_BYTE                mb_adaptive_frame_field_flag;                   /* u(1)  */
    DRM_BYTE                direct_8x8_inference_flag;                      /* u(1)  */
    DRM_BYTE                frame_cropping_flag;                            /* u(1)  */
    DRM_DWORD               frame_cropping_rect_left_offset;                /* ue(v) */
    DRM_DWORD               frame_cropping_rect_right_offset;               /* ue(v) */
    DRM_DWORD               frame_cropping_rect_top_offset;                 /* ue(v) */
    DRM_DWORD               frame_cropping_rect_bottom_offset;              /* ue(v) */
    DRM_BYTE                vui_parameters_present_flag;                    /* u(1)  */
    vui_seq_parameters_t    vui_seq_parameters;                             /* (sub-struct) */
} seq_parameter_set_rbsp_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_seq_parameter_set_rbsp_t_unsequenced
{
    seq_parameter_set_rbsp_mini_t   mini;

    DRM_DWORD               frame_cropping_rect_left_offset;
    DRM_DWORD               frame_cropping_rect_right_offset;
    DRM_DWORD               frame_cropping_rect_top_offset;
    DRM_DWORD               frame_cropping_rect_bottom_offset;

    DRM_LONG                ScalingList4x4[ 6 ][ 16 ];
    DRM_LONG                ScalingList8x8[ 2 ][ 64 ];
    DRM_LONG                offset_for_non_ref_pic;
    DRM_LONG                offset_for_top_to_bottom_field;
    DRM_LONG                offset_for_ref_frame[ 256 ];

    DRM_WORD                num_ref_frames_in_pic_order_cnt_cycle;
    DRM_BYTE                level_idc;
    DRM_BYTE                bit_depth_chroma_minus8;

    DRM_BYTE                UseDefaultScalingMatrix4x4Flag[ 6 ];
    DRM_BYTE                UseDefaultScalingMatrix8x8Flag[ 2 ];
    DRM_BYTE                seq_scaling_list_present_flag[ 8 ];

    DRM_BYTE                residue_transform_flag;
    DRM_BYTE                lossless_qpprime_flag;
    DRM_BYTE                seq_scaling_matrix_present_flag;
    DRM_BYTE                gaps_in_frame_num_value_allowed_flag;

    DRM_BYTE                mb_adaptive_frame_field_flag;
    DRM_BYTE                direct_8x8_inference_flag;
    DRM_BYTE                frame_cropping_flag;
    DRM_BYTE                vui_parameters_present_flag;

    vui_seq_parameters_t    vui_seq_parameters;
} seq_parameter_set_rbsp_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

/*
** END: SPS Definitions
*/

/*
** BEGIN: PPS Definitions
*/

#define DRM_MAX_NUM_SLICE_GROUPS        8
#define DRM_MAX_SLICE_GROUP_ID_NUM      1620

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_pic_parameter_set_rbsp_mini_t_sequenced
{
    DRM_BYTE    fIsSPS;                                                     /* (dictionary helper data, MUST be first, always FALSE for this struct) */
    DRM_WORD    pic_parameter_set_id;                                       /* ue(v) */
    DRM_WORD    seq_parameter_set_id;                                       /* ue(v) */
    DRM_BYTE    entropy_coding_mode_flag;                                   /* u(1)  */
    DRM_BYTE    pic_order_present_flag;                                     /* u(1)  */
    DRM_BYTE    num_slice_groups_minus1;                                    /* ue(v) */
    DRM_BYTE    slice_group_map_type;                                       /* ue(v) */
    DRM_DWORD   slice_group_change_rate_minus1;                             /* ue(v) */
    DRM_BYTE    num_ref_idx_l0_active_minus1;                               /* ue(v) */
    DRM_BYTE    num_ref_idx_l1_active_minus1;                               /* ue(v) */
    DRM_BYTE    weighted_pred_flag;                                         /* u(1)  */
    DRM_BYTE    weighted_bipred_idc;                                        /* u(2)  */
    DRM_LONG    pic_init_qp_minus26;                                        /* se(v) */
    DRM_BYTE    deblocking_filter_control_present_flag;                     /* u(1)  */
    DRM_BYTE    redundant_pic_cnt_present_flag;                             /* u(1)  */
} pic_parameter_set_rbsp_mini_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_pic_parameter_set_rbsp_mini_t_unsequenced
{
    DRM_BYTE    fIsSPS;                                                    /* (dictionary helper data, MUST be first, always FALSE for this struct) */
    DRM_BYTE    num_ref_idx_l0_active_minus1;
    DRM_BYTE    num_ref_idx_l1_active_minus1;
    DRM_BYTE    num_slice_groups_minus1;

    DRM_DWORD   slice_group_change_rate_minus1;
    DRM_LONG    pic_init_qp_minus26;

    DRM_WORD    pic_parameter_set_id;
    DRM_WORD    seq_parameter_set_id;

    DRM_BYTE    slice_group_map_type;
    DRM_BYTE    weighted_bipred_idc;
    DRM_BYTE    entropy_coding_mode_flag;
    DRM_BYTE    pic_order_present_flag;

    DRM_BYTE    weighted_pred_flag;
    DRM_BYTE    deblocking_filter_control_present_flag;
    DRM_BYTE    redundant_pic_cnt_present_flag;
} pic_parameter_set_rbsp_mini_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_pic_parameter_set_rbsp_t_sequenced
{
    pic_parameter_set_rbsp_mini_t   mini;
    /* DRM_WORD    pic_parameter_set_id;                                        */  /* Inside mini: ue(v) */
    /* DRM_WORD    seq_parameter_set_id;                                        */  /* Inside mini: ue(v) */

    /* DRM_BYTE    entropy_coding_mode_flag;                                    */  /* Inside mini: u(1)  */

    DRM_BYTE    transform_8x8_mode_flag;                                    /* u(1)  */

    DRM_BYTE    pic_scaling_matrix_present_flag;                            /* u(1)  */
    DRM_BYTE    pic_scaling_list_present_flag[8];                           /* u(1)  */
    DRM_LONG    ScalingList4x4[6][16];                                      /* se(v) */
    DRM_LONG    ScalingList8x8[2][64];                                      /* se(v) */
    DRM_BYTE    UseDefaultScalingMatrix4x4Flag[6];                          /* (computed) */
    DRM_BYTE    UseDefaultScalingMatrix8x8Flag[2];                          /* (computed) */

    /* if( pic_order_cnt_type < 2 )  in the sequence parameter set */
    /* DRM_BYTE    pic_order_present_flag;                                      */  /* Inside mini: u(1)  */
    /* DRM_BYTE    num_slice_groups_minus1;                                     */  /* Inside mini: ue(v) */
    /* DRM_BYTE    slice_group_map_type;                                        */  /* Inside mini: ue(v) */
    /* if( slice_group_map_type == 0 ) */
    DRM_DWORD   run_length_minus1[DRM_MAX_NUM_SLICE_GROUPS];                /* ue(v) */
    /* else if( slice_group_map_type == 2 ) */
    DRM_DWORD   top_left[DRM_MAX_NUM_SLICE_GROUPS];                         /* ue(v) */
    DRM_DWORD   bottom_right[DRM_MAX_NUM_SLICE_GROUPS];                     /* ue(v) */
    /* else if( slice_group_map_type == 3 || 4 || 5 */
    DRM_BYTE    slice_group_change_direction_flag;                          /* u(1)  */
    /* DRM_DWORD   slice_group_change_rate_minus1;                              */  /* Inside mini: ue(v) */
    /* else if( slice_group_map_type == 6 ) */
    DRM_DWORD   num_slice_group_map_units_minus1;                           /* ue(v) */

    DRM_BYTE    slice_group_id[DRM_MAX_SLICE_GROUP_ID_NUM];                 /* u(v) [complete MBAmap] */

    /* DRM_BYTE    num_ref_idx_l0_active_minus1;                                */  /* Inside mini: ue(v) */
    /* DRM_BYTE    num_ref_idx_l1_active_minus1;                                */  /* Inside mini: ue(v) */
    /* DRM_BYTE    weighted_pred_flag;                                          */  /* Inside mini: u(1)  */
    /* DRM_BYTE    weighted_bipred_idc;                                         */  /* Inside mini: u(2)  */
    /* DRM_LONG    pic_init_qp_minus26;                                         */  /* Inside mini: se(v) */
    DRM_LONG    pic_init_qs_minus26;                                        /* se(v) */
    DRM_LONG    chroma_qp_index_offset;                                     /* se(v) */

    DRM_LONG    second_chroma_qp_index_offset;                              /* se(v) */

    /* DRM_BYTE    deblocking_filter_control_present_flag;                      */  /* Inside mini: u(1)  */
    DRM_BYTE    constrained_intra_pred_flag;                                /* u(1)  */
    /* DRM_BYTE    redundant_pic_cnt_present_flag;                              */  /* Inside mini: u(1)  */
} pic_parameter_set_rbsp_t;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_pic_parameter_set_rbsp_t_unsequenced
{
    DRM_DWORD   run_length_minus1[ DRM_MAX_NUM_SLICE_GROUPS ];
    DRM_DWORD   top_left[ DRM_MAX_NUM_SLICE_GROUPS ];
    DRM_DWORD   bottom_right[ DRM_MAX_NUM_SLICE_GROUPS ];
    DRM_LONG    ScalingList4x4[ 6 ][ 16 ];
    DRM_LONG    ScalingList8x8[ 2 ][ 64 ];

    DRM_BYTE    slice_group_id[ DRM_MAX_SLICE_GROUP_ID_NUM ];

    DRM_DWORD   num_slice_group_map_units_minus1;

    DRM_LONG    pic_init_qs_minus26;
    DRM_LONG    chroma_qp_index_offset;
    DRM_LONG    second_chroma_qp_index_offset;

    DRM_BYTE    UseDefaultScalingMatrix4x4Flag[ 6 ];
    DRM_BYTE    UseDefaultScalingMatrix8x8Flag[ 2 ];
    DRM_BYTE    pic_scaling_list_present_flag[ 8 ];

    DRM_BYTE    transform_8x8_mode_flag;
    DRM_BYTE    pic_scaling_matrix_present_flag;
    DRM_BYTE    slice_group_change_direction_flag;
    DRM_BYTE    constrained_intra_pred_flag;

    pic_parameter_set_rbsp_mini_t   mini;
} pic_parameter_set_rbsp_t;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

/*
** END: PPS Definitions
*/

/*
** BEGIN: Slice Header Definitions
*/

#define DRM_MAX_REF_PIC_MARKING_NUM     66
#define DRM_MAX_LIST_SIZE               33
#define DRM_MAX_REFERENCE_PICTURES      32      /* H.264 allows 32 fields */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct  __tag_stRefPicListReordering_sequenced    /* spec. 7.3.3.1 */
{
    DRM_BYTE            ref_pic_list_reordering_flag_l0;                    /* u(1)  */
    DRM_DWORD           reordering_of_pic_nums_idc_l0[DRM_MAX_LIST_SIZE];   /* ue(v) */
    DRM_DWORD           abs_diff_pic_num_minus1_l0[DRM_MAX_LIST_SIZE];      /* ue(v) */
    DRM_DWORD           long_term_pic_idx_l0[DRM_MAX_LIST_SIZE];            /* ue(v) */
    DRM_BYTE            ref_pic_list_reordering_flag_l1;                    /* u(1)  */
    DRM_DWORD           reordering_of_pic_nums_idc_l1[DRM_MAX_LIST_SIZE];   /* ue(v) */
    DRM_DWORD           abs_diff_pic_num_minus1_l1[DRM_MAX_LIST_SIZE];      /* ue(v) */
    DRM_DWORD           long_term_pic_idx_l1[DRM_MAX_LIST_SIZE];            /* ue(v) */
} stRefPicListReordering;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct  __tag_stRefPicListReordering_unsequenced
{
    DRM_DWORD           reordering_of_pic_nums_idc_l0[ DRM_MAX_LIST_SIZE ];
    DRM_DWORD           abs_diff_pic_num_minus1_l0[ DRM_MAX_LIST_SIZE ];
    DRM_DWORD           long_term_pic_idx_l0[ DRM_MAX_LIST_SIZE ];
    DRM_DWORD           reordering_of_pic_nums_idc_l1[ DRM_MAX_LIST_SIZE ];
    DRM_DWORD           abs_diff_pic_num_minus1_l1[ DRM_MAX_LIST_SIZE ];
    DRM_DWORD           long_term_pic_idx_l1[ DRM_MAX_LIST_SIZE ];

    DRM_BYTE            ref_pic_list_reordering_flag_l0;
    DRM_BYTE            ref_pic_list_reordering_flag_l1;
} stRefPicListReordering;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_stPredWeightTable_sequenced          /* spec. 7.3.3.2 */
{
    DRM_BYTE      luma_log2_weight_denom;                                                   /* ue(v) */
    DRM_BYTE      chroma_log2_weight_denom;                                                 /* ue(v) */

    /* offset in [list][index][component] order */
    DRM_LONG      wp_offset[3][6][DRM_MAX_REFERENCE_PICTURES];                              /* se(v) */
    DRM_WORD      wp_round_luma;                                                            /* (computed) */
    DRM_WORD      wp_round_chroma;                                                          /* (computed) */

    /* weight in [list][index][component] order */
    DRM_LONG      wp_weight[3][2][DRM_MAX_REFERENCE_PICTURES];                              /* se(v) */
} stPredWeightTable;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_stPredWeightTable_unsequenced
{
    DRM_LONG      wp_offset[ 3 ][ 6 ][ DRM_MAX_REFERENCE_PICTURES ];
    DRM_LONG      wp_weight[ 3 ][ 2 ][ DRM_MAX_REFERENCE_PICTURES ];

    DRM_WORD      wp_round_luma;
    DRM_WORD      wp_round_chroma;

    DRM_BYTE      luma_log2_weight_denom;
    DRM_BYTE      chroma_log2_weight_denom;
} stPredWeightTable;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

/* Buffer structure for decoded reference picture marking commands */
typedef struct __tag_stDecRefPicMarking_sequenced
{
    DRM_DWORD memory_management_control_operation;   /* ue(v) */
    DRM_DWORD difference_of_pic_nums_minus1;         /* ue(v) */
    DRM_DWORD long_term_pic_num;                     /* ue(v) */
    DRM_DWORD long_term_frame_idx;                   /* ue(v) */
    DRM_BYTE  max_long_term_frame_idx_plus1;         /* ue(v) */
} stDecRefPicMarking;

#if DRM_H264_USE_SEQUENCED_STRUCTURES

typedef struct __tag_stSliceHeader_sequenced
{
    DRM_DWORD               first_mb_in_slice;                                          /* ue(v) [the number of first MB in this slice] */
    DRM_BYTE                slice_type;                                                 /* ue(v) [slice type (P, B or I)] */

    /* In the same picture, different slices can have different slice types */
    DRM_WORD                pic_parameter_set_id;                                       /* ue(v) [the ID of the picture parameter set the slice is referring to] */

    DRM_DWORD               frame_num;                                                  /* u(v)  [keep the same for the slices in the same picture] */
    DRM_BYTE                field_pic_flag;                                             /* u(1)  [keep the same for the slices in the same picture] */
    DRM_BYTE                bottom_field_flag;                                          /* u(1)  [keep the same for the slices in the same picture] */
    DRM_WORD                idr_pic_id;                                                 /* ue(v) [keep the same for the slices in the same picture] */
    DRM_DWORD               pic_order_cnt_lsb;                                          /* u(v)  [keep the same for the slices in the same picture] */
    DRM_LONG                delta_pic_order_cnt_bottom;                                 /* se(v) [keep the same for the slices in the same picture] */
    DRM_LONG                delta_pic_order_cnt[3];                                     /* se(v) [only used in poc decoding] */
    DRM_BYTE                redundant_pic_cnt;                                          /* ue(v) [no use in high profile/opt code path, used in default code path (need for parsing)] */
    DRM_BYTE                direct_spatial_mv_pred_flag;                                /* u(1)  [can be different for the slices in the same picture] */
    DRM_DWORD               num_ref_idx_lx_active[2];                                   /* (computed) */
    stRefPicListReordering  stRefPicListReorderingVar;                                  /* (sub-struct) [spec. 7.3.3.1] */
    DRM_BYTE                apply_weights;                                              /* (computed) */
    stPredWeightTable       stPredWeightTableVar;                                       /* (sub-struct) [spec. 7.3.3.2, tables for weighted MC] */

    DRM_BYTE                no_output_of_prior_pics_flag;                               /* u(1)  [keep the same for the slices in the same picture] */
    DRM_BYTE                long_term_reference_flag;                                   /* u(1)  [keep the same for the slices in the same picture] */
    DRM_BYTE                adaptive_ref_pic_buffering_flag;                            /* u(1)  [keep the same for the slices in the same picture] */
    DRM_BYTE                iNumRefPicMarking;                                          /* (calculated) [the number of MMCO, which keeps the same for the slices in the same picture] */
    stDecRefPicMarking      dec_ref_pic_marking_buffer[DRM_MAX_REF_PIC_MARKING_NUM];    /* ue(v) */

    DRM_BYTE                model_number;                                               /* ue(v) [the number of context models in a slice] */
    DRM_LONG                slice_qp_delta;                                             /* se(v) */
    DRM_LONG                iSliceQP;                                                   /* (calculated) */
    DRM_DWORD               LFDisableIdc;                                               /* ue(v)     [Disable loop filter on slice] */
    DRM_LONG                LFAlphaC0Offset;                                            /* se(v) * 2 [Alpha and C0 offset for filtering slice] */
    DRM_LONG                LFBetaOffset;                                               /* se(v) * 2 [Beta offset for filtering slice] */
    DRM_DWORD               slice_group_change_cycle;                                   /* u(v)      [keep the same for the slices in the same picture] */
} stSliceHeader;

#else   /* DRM_H264_USE_SEQUENCED_STRUCTURES */

typedef struct __tag_stSliceHeader_unsequenced
{
    DRM_DWORD               first_mb_in_slice;
    DRM_DWORD               frame_num;
    DRM_DWORD               LFDisableIdc;
    DRM_DWORD               slice_group_change_cycle;
    DRM_DWORD               pic_order_cnt_lsb;
    DRM_DWORD               num_ref_idx_lx_active[ 2 ];

    DRM_LONG                slice_qp_delta;
    DRM_LONG                iSliceQP;
    DRM_LONG                LFAlphaC0Offset;
    DRM_LONG                LFBetaOffset;
    DRM_LONG                delta_pic_order_cnt_bottom;
    DRM_LONG                delta_pic_order_cnt[ 3 ];

    DRM_WORD                pic_parameter_set_id;
    DRM_WORD                idr_pic_id;

    DRM_BYTE                slice_type;
    DRM_BYTE                redundant_pic_cnt;
    DRM_BYTE                apply_weights;
    DRM_BYTE                iNumRefPicMarking;

    DRM_BYTE                model_number;
    DRM_BYTE                field_pic_flag;
    DRM_BYTE                bottom_field_flag;
    DRM_BYTE                direct_spatial_mv_pred_flag;

    DRM_BYTE                no_output_of_prior_pics_flag;
    DRM_BYTE                long_term_reference_flag;
    DRM_BYTE                adaptive_ref_pic_buffering_flag;

    stDecRefPicMarking      dec_ref_pic_marking_buffer[ DRM_MAX_REF_PIC_MARKING_NUM ];
    stRefPicListReordering  stRefPicListReorderingVar;
    stPredWeightTable       stPredWeightTableVar;
} stSliceHeader;

#endif /* DRM_H264_USE_SEQUENCED_STRUCTURES */

/*
** END: Slice Header Definitions
*/

PRAGMA_PACK_POP

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_ParseSPS(
    __in                                                LPFN_H264_MEM_ALLOCATE    f_pfnMemAllocate,
    __in                                                LPFN_H264_MEM_FREE        f_pfnMemFree,
    __inout_opt                                         DRM_VOID                 *f_pCallbackContextAllowNULL,
    __in                                                DRM_DWORD                 f_cbSPS,
    __in_bcount( f_cbSPS )                        const DRM_BYTE                 *f_pbSPS,
    __inout                                             DRM_DWORD                *f_pcbSPSPPSDictionaryLocal,
    __deref_inout_bcount( *f_pcbSPSPPSDictionaryLocal ) DRM_BYTE                **f_ppbSPSPPSDictionaryLocal,
    __out                                               DRM_BOOL                 *f_pfSPSPPSDictionaryUpdated,
    __out_opt                                           DRM_DWORD                *f_piBit ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_ParsePPS(
    __in                                                LPFN_H264_MEM_ALLOCATE    f_pfnMemAllocate,
    __in                                                LPFN_H264_MEM_FREE        f_pfnMemFree,
    __inout_opt                                         DRM_VOID                 *f_pCallbackContextAllowNULL,
    __in                                                DRM_DWORD                 f_cbPPS,
    __in_bcount( f_cbPPS )                        const DRM_BYTE                 *f_pbPPS,
    __inout                                             DRM_DWORD                *f_pcbSPSPPSDictionaryLocal,
    __deref_inout_bcount( *f_pcbSPSPPSDictionaryLocal ) DRM_BYTE                **f_ppbSPSPPSDictionaryLocal,
    __out                                               DRM_BOOL                 *f_pfSPSPPSDictionaryUpdated,
    __out_opt                                           DRM_DWORD                *f_piBit ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API_VOID DRM_VOID DRM_CALL DRM_H264_IMPL_PerformDestructiveCopy(
    __in                                                DRM_DWORD                 f_cBitsOriginalSliceHeader,
    __in                                                DRM_DWORD                 f_cbNaluWeakRef,
    __in_bcount( f_cbNaluWeakRef )                const DRM_BYTE                 *f_pbNaluWeakRef,
    __in                                                DRM_DWORD                 f_cBitRemoveMapping,
    __in_ecount( f_cBitRemoveMapping )            const DRM_DWORD                *f_pdwBitRemoveMapping,
    __in                                                DRM_DWORD                 f_cbSliceHeader,
    __out_bcount( f_cbSliceHeader )                     DRM_BYTE                 *f_pbSliceHeader ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_ParseSliceHeader(
    __in                                                LPFN_H264_MEM_ALLOCATE    f_pfnMemAllocate,
    __in                                                LPFN_H264_MEM_FREE        f_pfnMemFree,
    __inout_opt                                         DRM_VOID                 *f_pCallbackContextAllowNULL,
    __in                                                DRM_BYTE                  f_bNalReferenceIDC,
    __in                                                DRM_BYTE                  f_bNaluType,
    __in                                                DRM_DWORD                 f_cbSliceHeader,
    __in_bcount( f_cbSliceHeader )                const DRM_BYTE                 *f_pbSliceHeader,
    __in                                                DRM_DWORD                 f_cbSPSPPSDictionaryLocal,
    __in_bcount( f_cbSPSPPSDictionaryLocal )      const DRM_BYTE                 *f_pbSPSPPSDictionaryLocal,
    __out_opt                                           DRM_DWORD                *f_piBit,
    __out_opt                                           DRM_DWORD                *f_pcBitRemoveMapping,
    __deref_opt_out_ecount( *f_pcBitRemoveMapping )     DRM_DWORD               **f_pdwBitRemoveMapping ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_DWORD DRM_CALL DRM_H264_IMPL_LocateStartCode(
    __in                                      DRM_DWORD     f_cbFrameRemaining,
    __in_bcount( f_cbFrameRemaining )   const DRM_BYTE     *f_pbFrameRemaining ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_LocateNalu(
    __in                                          DRM_DWORD       f_cbFrameRemaining,
    __in_bcount( f_cbFrameRemaining )       const DRM_BYTE       *f_pbFrameRemaining,
    __out_bcount( 1 )                             DRM_BYTE       *f_pbNaluType,
    __out                                         DRM_DWORD      *f_pcbNaluWeakRef,
    __deref_out_bcount( *f_pcbNaluWeakRef ) const DRM_BYTE      **f_ppbNaluWeakRef,
    __out                                         DRM_DWORD      *f_pcbConsumed ) DRM_NO_INLINE_ATTRIBUTE;

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_LocateAndVerifySliceHeader(
    __in                                                      LPFN_H264_MEM_ALLOCATE  f_pfnMemAllocate,
    __in                                                      LPFN_H264_MEM_FREE      f_pfnMemFree,
    __in_opt                                                  LPFN_H264_MEM_GET_TIME  f_pfnGetTime,
    __inout_opt                                               DRM_VOID               *f_pCallbackContextAllowNULL,
    __in                                                      DRM_DWORD               f_cbFrame,
    __in_bcount( f_cbFrame )                            const DRM_BYTE               *f_pbFrame,
    __in                                                      DRM_DWORD               f_cbSPSPPSDictionary,
    __in_bcount_opt( f_cbSPSPPSDictionary )             const DRM_BYTE               *f_pbSPSPPSDictionary,
    __out                                                     DRM_DWORD              *f_pcbSPSPPSDictionaryUpdated,
    __deref_out_bcount_opt( *f_pcbSPSPPSDictionaryUpdated )   DRM_BYTE              **f_ppbSPSPPSDictionaryUpdated,
    __out                                                     DRM_DWORD              *f_pcbSliceHeader,
    __deref_out_bcount( *f_pcbSliceHeader )                   DRM_BYTE              **f_ppbSliceHeader,
    __out_opt                                                 DRM_DWORD              *f_pcbConsumed ) DRM_NO_INLINE_ATTRIBUTE;

#if DRM_PERFORM_H264_PERF_ANALYSIS
extern DRM_UINT64 g_qwFrequency;
#endif /* DRM_PERFORM_H264_PERF_ANALYSIS */

DRM_NO_INLINE DRM_API DRM_RESULT DRM_CALL DRM_H264_IMPL_ReadBitsExpGolombCoded(
    __in                          DRM_DWORD    f_cbData,
    __in_bcount( f_cbData ) const DRM_BYTE    *f_pbData,
    __in                          DRM_DWORD    f_iBit,
    __out                         DRM_DWORD   *f_pcBits,
    __out                         DRM_DWORD   *f_pdwValueSuffix ) DRM_NO_INLINE_ATTRIBUTE;

EXIT_PK_NAMESPACE;

