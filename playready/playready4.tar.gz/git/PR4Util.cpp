#include <memory>
#include <vector>
#include <iostream>
#include <string.h>
#include "log.h"

#include <drmbytemanip.h>
#include <drmresults.h>
#include <drmbase64.h>
#include <drmdebug.h>
#include <drmerr.h>
#include "PR4Util.h"

#define PR4ChkDR(expr) do {                           \
            dr = ( expr );                            \
            if( DRM_FAILED( dr ) )                    \
            {                                         \
                LOGE("errcode: 0x%X; call: %s; infunc: %s()",  dr, #expr, __func__ ); \
                goto ErrorExit;                       \
            }                                         \
        } while(0)

namespace PR4Util
{

// Use the CDM lib functions to parse the header to get the version and the list of keyids.
// NOTE: The keyids are pointers into the header string and are wide-char, base64 encoded.
DRM_RESULT Header_GetInfo(
        const DRM_CONST_STRING      *f_pdstrWRMHEADER,
              eDRM_HEADER_VERSION   *f_pHeaderVersion,
              DRM_CONST_STRING     **f_ppdstrKIDs,
              DRM_DWORD             *f_pcbKIDs)
{
    DRM_RESULT          dr              = DRM_SUCCESS;
    DRM_DWORD           cKIDs           = 0;
    DRM_CONST_STRING   *pdstrKIDs       = NULL;

    PR4ChkDR( DRM_HDR_GetHeaderVersion( f_pdstrWRMHEADER, f_pHeaderVersion ) );

    PR4ChkDR( DRM_HDR_GetAttribute(
         f_pdstrWRMHEADER,
         NULL,
         DRM_HEADER_ATTRIB_KIDS,
         NULL,
         &cKIDs,
         &pdstrKIDs,
         0 ) );

    *f_ppdstrKIDs = pdstrKIDs;
    *f_pcbKIDs = cKIDs;

ErrorExit:
    return dr;
}

const char* Header_GetVersionStr( eDRM_HEADER_VERSION f_eHeaderVersion )
{
    switch( f_eHeaderVersion )
    {
    case DRM_HEADER_VERSION_2:
        return "2.0";
    case DRM_HEADER_VERSION_2_4:
        return "2.4";
    case DRM_HEADER_VERSION_4:
        return "4.0";
    case DRM_HEADER_VERSION_4_1:
        return "4.1";
    case DRM_HEADER_VERSION_4_2:
        return "4.2";
    case DRM_HEADER_VERSION_4_3:
        return "4.3";
    case DRM_HEADER_VERSION_UNKNOWN:
    default:
        return "Unknown";
    }
}

//
// KeyId Class Methods
//

const KeyId KeyId::EmptyKeyId;

// Constructors
KeyId::KeyId( const DRM_BYTE *f_pBytes )
{
    Init( f_pBytes );
}

KeyId::KeyId( const DRM_CONST_STRING & f_pdstrB64 )
{
    Init( f_pdstrB64 );
}
KeyId::KeyId( const DRM_ID *f_pDID )
{
    Init( f_pDID );
}

KeyId::KeyId( const DRM_ID &f_rDID )
{
    Init( f_rDID );
}

DRM_RESULT KeyId::Init( const DRM_BYTE *f_pBytes )
{
    DRM_RESULT dr = DRM_SUCCESS;

    Clear();

    memcpy( m_bytes, f_pBytes, DRM_ID_SIZE );

    keyIdOrder = KEYID_ORDER_GUID_LE;

    return dr;
}

DRM_RESULT KeyId::Init( const DRM_ID *f_pDID )
{
    DRM_RESULT dr = DRM_SUCCESS;

    Clear();

    memcpy( m_bytes, &f_pDID->rgb[0], DRM_ID_SIZE );

    keyIdOrder = KEYID_ORDER_GUID_LE;

    return dr;
}

DRM_RESULT KeyId::Init( const DRM_ID & f_rDID )
{
    return Init( &f_rDID );
}

DRM_RESULT KeyId::InitFromUuid( const DRM_BYTE *f_pDID )
{
    DRM_RESULT dr = DRM_SUCCESS;

    Clear();

    memcpy( m_bytes, &f_pDID[0], DRM_ID_SIZE );

    keyIdOrder = KEYID_ORDER_UUID_BE;

    return dr;
}

// This is MS WRMHEADER oriented.  When parsing using the CDM xml funcs,
// header values are returned in a DRM_CONST_STRING type, base64 encoded,
// and Guid/LE format
DRM_RESULT KeyId::Init( const DRM_CONST_STRING &f_pdstrB64 )
{
    DRM_RESULT dr = DRM_SUCCESS;

    DRM_DWORD cBytes = DRM_ID_SIZE;

    Clear();

    PR4ChkDR( DRM_B64_DecodeW( &f_pdstrB64, &cBytes, m_bytes, 0 ) );

    keyIdOrder = KEYID_ORDER_GUID_LE;

    ErrorExit:

    return dr;
}

const char* KeyId::HexStr()
{
    if ( m_hexStr.empty() )
    {
        char hex[64];
        ::memset(hex, 0, 64);
        for (int i = 0; i < DRM_ID_SIZE; i++)
        {
            hex[i * 2] = "0123456789abcdef"[m_bytes[i] >> 4];
            hex[i * 2 + 1] = "0123456789abcdef"[m_bytes[i] & 0x0F];
        }
        m_hexStr = hex;
    }

    return m_hexStr.c_str();
}

// Use the PR4 lib to base64 encode the m_mbytes array.
const char* KeyId::B64Str()
{
    DRM_RESULT dr = DRM_SUCCESS;
    if ( m_base64Str.empty() )
    {
        char b64[64];
        DRM_DWORD cbB64 = 64;
        ::memset( b64, 0, 64 );
        PR4ChkDR( DRM_B64_EncodeA( m_bytes, DRM_ID_SIZE, b64, &cbB64, 0 ) );

        m_base64Str = b64;
    }

    ErrorExit:

    return m_base64Str.c_str();
}

DRM_BYTE* KeyId::Data()
{
    return m_bytes;
}

bool KeyId::Empty()
{
    return *this == EmptyKeyId;
}

KeyId& KeyId::Clear()
{
    m_hexStr.clear();
    m_base64Str.clear();
    ZEROMEM( m_bytes, DRM_ID_SIZE );
    keyIdOrder = KEYID_ORDER_UNKNOWN;

    return *this;
}

KeyId& KeyId::ToggleFormat()
{
    DRM_BYTE tmp;

    if ( keyIdOrder != KEYID_ORDER_UNKNOWN )
    {
        tmp = m_bytes[3];
        m_bytes[3] = m_bytes[0];
        m_bytes[0] = tmp;
        tmp = m_bytes[2];
        m_bytes[2] = m_bytes[1];
        m_bytes[1] = tmp;
        tmp = m_bytes[5];
        m_bytes[5] = m_bytes[4];
        m_bytes[4] = tmp;
        tmp = m_bytes[7];
        m_bytes[7] = m_bytes[6];
        m_bytes[6] = tmp;

        if ( keyIdOrder == KEYID_ORDER_GUID_LE )
            keyIdOrder = KEYID_ORDER_UUID_BE;
        else
            keyIdOrder = KEYID_ORDER_GUID_LE;
    }
    else
    {
        LOGW( "Attempt to swap empty keyId" );
    }

    m_hexStr.clear();
    m_base64Str.clear();

    return *this;
}

KeyId& KeyId::Uuid()
{
    if ( keyIdOrder == KEYID_ORDER_GUID_LE )
    {
        ToggleFormat();
    }
    return *this;
}

KeyId& KeyId::Guid()
{
    if ( keyIdOrder == KEYID_ORDER_UUID_BE )
    {
        ToggleFormat();
    }
    return *this;
}

bool KeyId::operator< ( const KeyId &keyId ) const
{
    if ( memcmp(keyId.m_bytes, m_bytes, DRM_ID_SIZE) < 0 )
        return true;
    return false;
}

// Overload operator== to check both guid and uuid formats for equality.
bool KeyId::operator== ( const KeyId &keyId )
{
    bool areEqual = false;

    // https://docs.microsoft.com/en-us/playready/specifications/mpeg-dash-playready#225-kid-byte-order
    //
    // No matter byte order, last 8 will be the same
    if ( memcmp(&m_bytes[8], &(keyId.m_bytes[8]), 8) == 0 )
    {
        // test first 8
        if ( memcmp(keyId.m_bytes, m_bytes, 8) == 0 )
        {
            areEqual = true;
        }
        else
        {
            ToggleFormat();
            areEqual = ( memcmp(keyId.m_bytes, m_bytes, DRM_ID_SIZE ) == 0 );
            ToggleFormat();
        }
    }

    return areEqual;
}

KeyId& KeyId::operator=( const KeyId &keyId )
{
    Clear();
    keyIdOrder = keyId.keyIdOrder;
    ::memcpy( m_bytes, keyId.m_bytes, DRM_ID_SIZE );

    return *this;
}

KeyId& KeyId::operator=( const DRM_ID & f_rDID )
{
    Init( f_rDID );
    return *this;
}

};
