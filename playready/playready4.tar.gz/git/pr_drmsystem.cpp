#ifdef USE_DISPLAY_SETTINGS

#include "pr_drmsystem.h"
#include "log.h"
#include <string.h>

using namespace std;

namespace CDMi {


static void dsHdmiEventHandler(const char *owner, IARM_EventId_t eventId, void *data, size_t len);
static void DisplResolutionHandler(const char *owner, IARM_EventId_t eventId, void *data, size_t len);

CPRDrmSystem::CPRDrmSystem()
        : mDRMinitialized(false),
        m_rfcFeatureHDCP22(false)
{    
    LOGD("CPRDrmSystem()");

    LOGD("initializing IARM bus...\n");

    if(IARM_Bus_Init("OCDM-Playready") != IARM_RESULT_SUCCESS)
    {
        LOGE("error initializing IARM Bus!\n");
    }

    if(IARM_Bus_Connect() != IARM_RESULT_SUCCESS)
    {
        LOGE("error connecting to IARM Bus!\n");
    }
    try
    {
        LOGD("initializing Device Manager...");
        ::device::Manager::Initialize();
    }
    catch (const std::exception e)
    {
        LOGE("exception while initializing device manager %s", e.what());
    }

    LOGD("registering DSMGR events...");
    IARM_Bus_RegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_HDMI_HOTPLUG, dsHdmiEventHandler);
    IARM_Bus_RegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_HDCP_STATUS, dsHdmiEventHandler);
    IARM_Bus_RegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_RES_POSTCHANGE, DisplResolutionHandler);

}

CPRDrmSystem::~CPRDrmSystem()
{
    LOGD("~CPRDrmSystem()");

    LOGD("unregistering IARM DSMGR events...");
    IARM_Bus_UnRegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_HDMI_HOTPLUG);
    IARM_Bus_UnRegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_HDCP_STATUS);
    IARM_Bus_UnRegisterEventHandler(IARM_BUS_DSMGR_NAME,IARM_BUS_DSMGR_EVENT_RES_POSTCHANGE);

    LOGD("deinitializing device manager...");
    try
    {
        ::device::Manager::DeInitialize();
    }
    catch (const std::exception e)
    {
       LOGE("exception while shutting down device manager and iarm bus! %s", e.what());
    }

    LOGD("disconnecting from IARM Bus...\n");
    IARM_Bus_Disconnect();

    IARM_Bus_Term();

    mDRMinitialized = false;
}

bool CPRDrmSystem::isDRMinitialized()
{
    std::lock_guard<std::mutex> lock(m_drmSystemMutex);

    return mDRMinitialized;
}

DRM_RESULT CPRDrmSystem::initialize()
{
    std::lock_guard<std::mutex> lock(m_drmSystemMutex);
    
    LOGD("CPRDrmSystem::initialize()");
    
    mDRMinitialized = true;

    m_rfcFeatureHDCP22 = isRFCfeatureHDCP22On();

    return DRM_SUCCESS;
}

std::vector<struct VideoOutputInfo> CPRDrmSystem::getActiveVideoOutputs()
{
    std::lock_guard<std::mutex> lock(m_drmSystemMutex);

    return mActiveVideoOutputs;
}

void CPRDrmSystem::resetAnalogOutputs()
{
    device::List<device::VideoOutputPort> vPorts = device::Host::getInstance().getVideoOutputPorts();
    for (size_t i = 0; i < vPorts.size(); i++) {
        device::VideoOutputPort &vPort = vPorts.at(i);
        if(vPort.getType().getName() != "HDMI" && !vPort.isEnabled())
        {
            LOGI("enabling  analog port %s", vPort.getName().c_str());
            vPort.enable();
        }
    }
}

void CPRDrmSystem::disableAnalogOutputs()
{
    device::List<device::VideoOutputPort> vPorts = device::Host::getInstance().getVideoOutputPorts();
    for (size_t i = 0; i < vPorts.size(); i++) {
        device::VideoOutputPort &vPort = vPorts.at(i);
        if(vPort.getType().getName() != "HDMI" && vPort.isEnabled())
        {
            LOGI("disabling analog port %s", vPort.getName().c_str());
            vPort.disable();
        }
    }
}
void CPRDrmSystem::setActiveVideoOutputs()
{
    std::lock_guard<std::mutex> lock(m_drmSystemMutex);

    mActiveVideoOutputs.clear();
    try {

        device::List<device::VideoOutputPort> vPorts = device::Host::getInstance().getVideoOutputPorts();
        for (size_t i = 0; i < vPorts.size(); i++) {
            device::VideoOutputPort &vPort = vPorts.at(i);
            LOGI("VideoOuputPort Name- [%s] =======================\r",    vPort.getName().c_str());
            LOGI("\t Enabled- [%s]\r",    vPort.isEnabled() ? "Yes" : "No");
            bool isActive = true;
            try {
                isActive  = vPort.isActive();
                LOGI("\t Active - [%s]\r",    isActive ? "Yes" : "No");
            }
            catch (device::UnsupportedOperationException &e) {
                LOGI("RxSense is NOT supported\r");
            }

            bool isConnected = vPort.isDisplayConnected();
            LOGI("\t Connected- [%s]\r", isConnected ? "Yes" : "No");
            LOGI("\t Content Protected- [%s]\r",    vPort.isContentProtected() ? "Yes" : "No");
            LOGI("\t Port Type- [%s]\r",   vPort.getType().getName().c_str());
            LOGI("\t\tIs HDCP Supported- [%s]\r",    vPort.getType().isHDCPSupported() ? "Yes" : "No");
            LOGI("\t\tIs HDCP Authenticated- [%s]",    (vPort.getHDCPStatus() == dsHDCP_STATUS_AUTHENTICATED) ? "Yes" : "No");
            //LOGI("\t\tCurrent Resolution- [%s]\r",    vPort.getResolution().getName().c_str());
            LOGI(" ==========================================\r\r");

            if(vPort.isEnabled() && isActive && isConnected){
                VideoOutputInfo vidOutInfo;

                vidOutInfo.name = vPort.getName().c_str();
                vidOutInfo.type = vPort.getType().getName().c_str();

                if(vidOutInfo.type == "HDMI"){
                    vidOutInfo.hdcpVersion = ((vPort.getHDCPStatus() == dsHDCP_STATUS_AUTHENTICATED) && vPort.isContentProtected()) ? GetHDCPVersion(vPort) : HDCP_NOT_ENGAGED;
                }else{
                    vidOutInfo.hdcpVersion = HDCP_NOT_ENGAGED;
                }
                mActiveVideoOutputs.push_back(vidOutInfo);
            }

        }
    }catch (const std::exception e) {
        LOGE("exception from devicesettings....%s", e.what());
    }
#if 0
    VideoOutputInfo vidOutInfo;

    vidOutInfo.name = "HDMI0";
    vidOutInfo.type = "HDMI";
    vidOutInfo.hdcpVersion = HDCP_1_4;
    mActiveVideoOutputs.push_back(vidOutInfo);
#endif

    return;
}

#define TEMP_BUF_LEN 80
bool CPRDrmSystem::isRFCfeatureHDCP22On()
{
    bool                 retVal         = false;
    char const * const   strFeature     = "PlayreadyHDCP22check";
    char const * const   strCommand     = ". /lib/rdk/isFeatureEnabled.sh";
    size_t               nRead          = 0;
    char                 strData[TEMP_BUF_LEN] = { 0 };

    std::string strCmd(strCommand);
    strCmd.append(" ");
    strCmd.append(strFeature);

    FILE* fp = popen(strCmd.c_str(), "r");
    if(fp != NULL) {
        nRead = fread(strData, 1, TEMP_BUF_LEN - 1, fp);
        pclose(fp);
        if (nRead != 0)
        {
            printf("isRFCfeatureHDCP22On feature [ %s ] returned %s\n", strFeature, strData);
            if(strtol(strData, NULL, 10) == 1) {
                retVal = true;
            }
        }
        else {
            printf("isRFCfeatureHDCP22On nRead = %u\n", nRead);
        }
    }
    else {
        printf("isRFCfeatureHDCP22On popen failed errno = %d (%s)\n", errno, strerror(errno));
    }

    return retVal;
}

bool CPRDrmSystem::SetHdmiPreferences(dsHdcpProtocolVersion_t hdcpCurrentProtocol)
{
    bool ret = false;


#if (NEXUS_PLATFORM_VERSION_MAJOR>=16)
    if(!JoinNxClient()) {
        LOGE("%s: Could not join NxClient");
        return false;
    }
    // Get display settings
    NxClient_DisplaySettings displaySettings;
    NxClient_GetDisplaySettings(&displaySettings);
    LOGW("Display currently set to %d current protocol = %d ",
            displaySettings.hdmiPreferences.version, hdcpCurrentProtocol);
    // Set HDMI Preferences.
    switch(hdcpCurrentProtocol) {
    case dsHDCP_VERSION_2X:
        displaySettings.hdmiPreferences.version = NxClient_HdcpVersion_eHdcp22;
        break;
    case dsHDCP_VERSION_1X:
        displaySettings.hdmiPreferences.version = NxClient_HdcpVersion_eAuto;
        break;
    case dsHDCP_VERSION_MAX:
        // This setting is used for the hot plug disconnect.
        displaySettings.hdmiPreferences.version = NxClient_HdcpVersion_eAuto;
        LOGE("Setting hdmiPreferences to %d [NxClient_HdcpVersion_eAuto]",
                  displaySettings.hdmiPreferences.version);
        break;
    }
    // Set display settings
    LOGW("Display HDMI preferences set to %d", displaySettings.hdmiPreferences.version);
    NEXUS_Error retVal = NxClient_SetDisplaySettings(&displaySettings);
    if(retVal) {
        LOGE("NxClient_SetDisplaySettings FAILED retVal = %d", retVal);
    }

    ret = !retVal;

    ReleaseNXClient();
#endif

    return ret;
}

dsHdcpProtocolVersion_t CPRDrmSystem::GetHdmiPreferences()
{
    dsHdcpProtocolVersion_t retVal = dsHDCP_VERSION_MAX;

#if (NEXUS_PLATFORM_VERSION_MAJOR>=16)

    if(!JoinNxClient()) {
        LOGE("%s: Could not join NxClient");
        return dsHDCP_VERSION_MAX;
    }

    // Get display settings
    NxClient_DisplaySettings displaySettings;
    NxClient_GetDisplaySettings(&displaySettings);
    // Set HDMI Preferences.
    switch(displaySettings.hdmiPreferences.version) {
    case NxClient_HdcpVersion_eHdcp22:
        retVal = dsHDCP_VERSION_2X;
        break;
    }

    ReleaseNXClient();
#endif

    return retVal;
}

HDCPVersion CPRDrmSystem::GetHDCPVersion(device::VideoOutputPort& vPort)
{
    HDCPVersion             retVal                   = HDCP_NOT_ENGAGED;
    bool                    isConnected              = false;
    bool                    isHDCPCompliant          = false;
    bool                    isHDCPEnabled            = true;
    dsHdcpProtocolVersion_t hdcpProtocol             = dsHDCP_VERSION_MAX;
    dsHdcpProtocolVersion_t hdcpReceiverProtocol     = dsHDCP_VERSION_MAX;
    dsHdcpProtocolVersion_t hdcpCurrentProtocol      = dsHDCP_VERSION_MAX;

    try {
        isConnected        = vPort.isDisplayConnected();
        hdcpProtocol       = (dsHdcpProtocolVersion_t)vPort.getHDCPProtocol();
        if(isConnected) {
            isHDCPCompliant          = (vPort.getHDCPStatus() == dsHDCP_STATUS_AUTHENTICATED);
            isHDCPEnabled            = vPort.isContentProtected();
            hdcpReceiverProtocol     = (dsHdcpProtocolVersion_t)vPort.getHDCPReceiverProtocol();
            hdcpCurrentProtocol      = (dsHdcpProtocolVersion_t)vPort.getHDCPCurrentProtocol();
        }
        else {
            isHDCPCompliant = false;
            isHDCPEnabled = false;
        }
    }
    catch (const std::exception e) {
        LOGE("DeviceSettings exception caught in %s", __FUNCTION__);
    }

    if(isHDCPEnabled) {
        LOGI("detected the following HDCP connections Receiver Protocol: %d, Current Protocol: %d",
                hdcpReceiverProtocol, hdcpCurrentProtocol);
        if(hdcpCurrentProtocol == dsHDCP_VERSION_2X) {
            // HDCP 2.2 Set streamID_type to 1 to ensure that downstream
            // devices do not allow copying of the data
            retVal = HDCP_2_2;
        }
        else {
            retVal = HDCP_1_4;
        }
    }
    else {
        LOGE("DeviceSettings HDCP is not enabled, connected = %d", isConnected);
        CPRDrmSystem::instance().SetHdmiPreferences(dsHDCP_VERSION_MAX);
    }

    LOGI("GetHDCPVersion: detected HDCP version %d", retVal);

    if(retVal == HDCP_NOT_ENGAGED) {
        retVal = HDCP_1_4;
        LOGE("GetHDCPVersion: Did not detect HDCP version defaulting to 1.4 (%d)", retVal);
    }

    return retVal;
}


static void DisplResolutionHandler(const char *owner, IARM_EventId_t eventId, void *data, size_t len)
{

    LOGD("Display resolution event handler called...");
    switch (eventId) {
        case IARM_BUS_DSMGR_EVENT_RES_PRECHANGE:
            LOGD("Received IARM_BUS_DSMGR_EVENT_RES_PRECHANGE");
            break;
        case IARM_BUS_DSMGR_EVENT_RES_POSTCHANGE:
            {
                int dw = 1280;
                int dh = 720;

                IARM_Bus_DSMgr_EventData_t *eventData = (IARM_Bus_DSMgr_EventData_t *)data;
                dw = eventData->data.resn.width ;
                dh = eventData->data.resn.height ;

                LOGI("Received IARM_BUS_DSMGR_EVENT_RES_POSTCHANGE  event width:%d height:%d", dw, dh);
                CPRDrmSystem::instance().setActiveVideoOutputs();
            }
            break;

          default:
            LOGD("Received unknown event %d", eventId);
           break;
    }
}

void dsHdmiEventHandler(const char *owner, IARM_EventId_t eventId, void *data, size_t len)
{
    LOGD("HDMI event handler called...");
    switch (eventId) {
        case IARM_BUS_DSMGR_EVENT_HDMI_HOTPLUG :
        {

            IARM_Bus_DSMgr_EventData_t *eventData = (IARM_Bus_DSMgr_EventData_t *)data;
            int hdmi_hotplug_event = eventData->data.hdmi_hpd.event;

            const char *hdmihotplug = (hdmi_hotplug_event == dsDISPLAY_EVENT_CONNECTED) ? "connected" : "disconnected";
            LOGI("Received IARM_BUS_DSMGR_EVENT_HDMI_HOTPLUG  event data:%d status: %s", hdmi_hotplug_event, hdmihotplug);
            if(hdmi_hotplug_event != dsDISPLAY_EVENT_CONNECTED) {
                // Disconnected, set the HDMI Preferences to auto
                LOGI("Received IARM_BUS_DSMGR_EVENT_HDMI_HOTPLUG Disconnected");
                CPRDrmSystem::instance().SetHdmiPreferences(dsHDCP_VERSION_MAX);
            }

            CPRDrmSystem::instance().setActiveVideoOutputs();
        }
        break;

        case IARM_BUS_DSMGR_EVENT_HDCP_STATUS :
        {
            IARM_Bus_DSMgr_EventData_t *eventData = (IARM_Bus_DSMgr_EventData_t *)data;
            int hdcpStatus = eventData->data.hdmi_hdcp.hdcpStatus;
            const char *hdcpStatusStr = (hdcpStatus == dsHDCP_STATUS_AUTHENTICATED) ? "authenticated" : "authentication failure";
            LOGI("Received IARM_BUS_DSMGR_EVENT_HDCP_STATUS  event data:%d status:%s", hdcpStatus, hdcpStatusStr);
            CPRDrmSystem::instance().setActiveVideoOutputs();
        }
        break;

        default:
            LOGD("Received unknown IARM bus event:%d", eventId);
            break;
   }
}

bool CPRDrmSystem::JoinNxClient()
{
#if (NEXUS_PLATFORM_VERSION_MAJOR>=16)
    NEXUS_Error err;
    NxClient_JoinSettings joinSettings;

    NxClient_GetDefaultJoinSettings(&joinSettings);
    snprintf(joinSettings.name, NXCLIENT_MAX_NAME, "%s", "ocdm-playready\0");
    joinSettings.timeout = 5; // seconds

    err = NxClient_Join(&joinSettings);
    if (err) {
        LOGE("NxClient_Join failed err = %d", err);
        return false;
    }
#endif
    return true;
}

void CPRDrmSystem::ReleaseNXClient()
{
#if (NEXUS_PLATFORM_VERSION_MAJOR>=16)
    NxClient_Uninit();
#endif
}

} // namespace CDMi

#endif // USE_DISPLAY_SETTINGS
