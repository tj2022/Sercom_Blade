#ifndef LOG_H_
#define LOG_H_

#include "cdmi.h"


#define CDMS_ERR_OFFSET 400000000
#define CDMS_ERR_SEQ      1000000

#define OCDMI_ERR_OFFSET 500000000
#define OCDMI_ERR_SEQ      1000000

#define OCDMI_INTERNAL_ERR_OFFSET 600000000
#define OCDMI_INTERNAL_ERR_SEQ      1000000


namespace CDMi {

// Simple logging class. The implementation is platform dependent.

typedef enum{
  NO_ERROR,
  INDIVIDUALIZATION_SERVER_ERROR,
  SYM_LINK_ERROR,
  SAGE_SVP_ERROR,
  CDM_CREATION_ERROR,
  CDM_CERT_ERROR,
  DEVICE_INFO_ERROR,
  THREAD_CREATE_ERROR,
  THREAD_ERROR,
  INVALID_PARAMETER_ERROR,
  INVALID_RESPONSE_ERROR,
  HTTP_ERROR,
  DECRYPT_ERROR,
  KEY_ERROR,
  KEY_STORAGE_ERROR,
  UNEXPECTED_ERROR
} PrCdmiErrors;

typedef enum{
  SILENT = -1,
  ERROR = 0,
  WARNING = 1,
  INFO = 2,
  DEBUG = 3,
  VERBOSE = 4
} LogLevel;



extern LogLevel pr_log_level; //global variable used in Log function.
int SetPlayreadyLoggingLevel();
void Log(const char* file, int line, LogLevel ll, const char* fmt, ...);
void LogTelemetry(const char* file, int line,  int x);
// Log APIs



#define LOGT(X) LogTelemetry(__FILE__, __LINE__, X)
#define LOGE(...) Log(__FILE__, __LINE__, CDMi::ERROR,  __VA_ARGS__)

#define LOGW(...) Log(__FILE__, __LINE__, CDMi::WARNING,  __VA_ARGS__)
#define LOGI(...) Log(__FILE__, __LINE__, CDMi::INFO, __VA_ARGS__)
#define LOGD(...) Log(__FILE__, __LINE__, CDMi::DEBUG,  __VA_ARGS__)
#define LOGV(...) Log(__FILE__, __LINE__, CDMi::VERBOSE,  __VA_ARGS__)

}  // namespace CDMi

#endif  //LOG_H_
