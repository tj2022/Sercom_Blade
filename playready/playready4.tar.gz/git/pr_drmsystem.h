#pragma once

#include "MediaSession.h"
#include <mutex>

#ifdef USE_DISPLAY_SETTINGS
#include "manager.hpp"
#include "host.hpp"
#include "videoResolution.hpp"
#include "videoOutputPort.hpp"
#include "videoOutputPortType.hpp"
#include <libIARM.h>
#include <libIBus.h>
#include "libIBusDaemon.h"
#include "dsMgr.h"
#include "dsDisplay.h"
#include <iarmUtil.h>
#include "unsupportedOperationException.hpp"

#ifdef USE_SAGE_SVP
#include "nexus_config.h"
#include "nexus_read_otp_id.h"
#include <nexus_platform.h> // HDMI output settings
#include <nxclient.h>    // HDR display settings
#endif

using namespace std;

namespace CDMi {

class CPRDrmSystem {
public:
    
    static CPRDrmSystem& instance()  {
        static CPRDrmSystem instance;
        return instance;
    }
    
    ~CPRDrmSystem();
    
    DRM_RESULT initialize();

    bool isDRMinitialized();

    void setActiveVideoOutputs();
    std::vector<struct VideoOutputInfo> getActiveVideoOutputs();

    void resetAnalogOutputs();
    void disableAnalogOutputs();

#ifdef USE_DISPLAY_SETTINGS
    bool SetHdmiPreferences(dsHdcpProtocolVersion_t hdcpCurrentProtocol);
    dsHdcpProtocolVersion_t GetHdmiPreferences();
#endif
    bool getRFCfeatureHDCP22() {return m_rfcFeatureHDCP22;}

private:
    CPRDrmSystem();
#ifdef USE_DISPLAY_SETTINGS
    HDCPVersion GetHDCPVersion(device::VideoOutputPort& vPort);
    bool JoinNxClient();
    void ReleaseNXClient();
#endif
    bool             isRFCfeatureHDCP22On();
    bool             m_rfcFeatureHDCP22;
    std::mutex       m_drmSystemMutex;

    bool             mDRMinitialized;

    std::vector<struct VideoOutputInfo> mActiveVideoOutputs;

};
    
}// namespace CDMi

#endif
