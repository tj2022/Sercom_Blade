#include "log.h"
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include <string>
#include <stdexcept>
#include <fstream>
#include <iostream>

#define VER_STR "000.001.000"
#define CDMI_LOG_XV1 678598463
#define CDMI_LOG_XV2 262908887

namespace CDMi {

/**
 * Sets playready logging level at run-time
 * when by reading in pr_log_level
 * from /opt/wpecdmi.cfg. Must restart wpecdmi
 * to change logging level. Defaults to 0(errors) if there
 * is an invalid value or a problem reading the file.
 *
 * @return the logging level to use.
 *
 * @execution Synchronous
 * @sideeffect None
 */
int SetPlayreadyLoggingLevel() {
  std::string delimiter = "pr_log_level=";
  std::string line;
  std::string value;
  size_t position = 0;
  int log_level = 0;
  bool level_found = false;
  std::ifstream inFile("/opt/wpecdmi.cfg");

  if (inFile.is_open()) {
    while (getline(inFile, line)) {
      if ((position = line.find(delimiter)) != std::string::npos) {
        try {
          value = line.substr(position+delimiter.size());
          log_level = std::stoi(value);
          level_found = true;
          std::cout << "pr_log_level="<< log_level << std::endl;
        }
        catch (std::invalid_argument& e) {
          std::cout << "Invalid input exception caught: " << e.what() << std::endl;
        }
        catch (std::out_of_range& e) {
          std::cout << "Out of range exception caught: " << e.what() << std::endl;
        }
      }
    }
    inFile.close();
  } else {
    std::cout << "Unable to open /opt/wpecdmi.cfg" << std::endl;
  }

  if (!level_found) {
    std::cout << "Defaulting to pr_log_level 2 (Info)" << std::endl;
    log_level = 2;
  }

  return log_level;
}

void Log(const char* file, int line, LogLevel ll, const char* fmt, ...) {

  if (pr_log_level < ll) return;

  std::string file_ver = std::string(file);
  file_ver.append(VER_STR);


  std::string ls;

  if (ll == ERROR)
    ls = "ERROR";
  else if (ll == WARNING)
    ls = "WARNING";
  else if (ll == INFO)
     ls = "INFO";
  else if (ll == DEBUG)
    ls = "DEBUG";
  else if (ll == VERBOSE)
    ls = "VERBOSE";
  else
     return;

  //fprintf(stderr, "PRCDMi_LOG %s:%s(%d) ",ls.c_str(), file_ver.c_str(), line);
  fprintf(stderr, "PRCDMi_LOG %s: ",ls.c_str());

  va_list vl;
  va_start(vl, fmt);
  vfprintf(stderr, fmt, vl);
  va_end(vl);

  fprintf(stderr, "\n");

  fflush(stderr);
}

void LogTelemetry(const char* file, int line, int x)
{
  std::string file_ver = std::string(file);
  file_ver.append(VER_STR);

  unsigned int lnxv = (unsigned int)(((unsigned int)line ^
              (unsigned int)CDMI_LOG_XV1) ^ (unsigned int)CDMI_LOG_XV2);

  fprintf(stderr, "_PRCDM: %s-%u, %d\n", file_ver.c_str(), lnxv, x);
  fflush(stderr);
}

}  // namespace CDMi
