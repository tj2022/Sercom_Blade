#ifndef PR4UTIL_H_
#define PR4UTIL_H_

#include <string>
#include <vector>
#include <utility>
#include <memory>

#include <drmmanagertypes.h>
#include <drmheaderparser.h>


namespace PR4Util
{

const char* Header_GetVersionStr( eDRM_HEADER_VERSION f_eHeaderVersion );

DRM_RESULT Header_GetInfo(
        const DRM_CONST_STRING      *f_pdstrWRMHEADER,
              eDRM_HEADER_VERSION   *f_pHeaderVersion,
              DRM_CONST_STRING     **f_ppdstrKIDs,
              DRM_DWORD             *f_pcbKIDs);

// KeyId
//
// Class to help with converting/displaying/comparing a uint8_t array of DRM_ID_SIZE
//
// Other than the InitFromUuid(), the bytes are assumed to initially be in Guid/LE format.
// This is the format that is used for the KeyId in the WRMHEADER.
// ToggleFormat(), Guid(), Uuid() can be used to change the format between Guid-LE and
// uuid-BE format.
//
// https://docs.microsoft.com/en-us/playready/specifications/mpeg-dash-playready#225-kid-byte-order
class KeyId
{
public:

    enum KeyIdOrder { KEYID_ORDER_GUID_LE, KEYID_ORDER_UUID_BE, KEYID_ORDER_UNKNOWN };

    static const KeyId EmptyKeyId;

    // assume at least DRM_ID size
    KeyId( const DRM_BYTE * );
    KeyId( const DRM_ID * );
    KeyId( const DRM_ID & );
    KeyId( const DRM_CONST_STRING & );
    KeyId& operator=( const KeyId & );
    KeyId& operator=( const DRM_ID & );
    KeyId(){ Clear(); }
    ~KeyId(){ }

    DRM_RESULT InitFromUuid( const DRM_BYTE * );
    DRM_RESULT Init( const DRM_BYTE * );
    DRM_RESULT Init( const DRM_CONST_STRING & );
    DRM_RESULT Init( const DRM_ID * );
    DRM_RESULT Init( const DRM_ID & );

    const char* HexStr();
    const char* B64Str();
    KeyId& ToggleFormat();
    KeyId& Clear();
    KeyId& Uuid();
    KeyId& Guid();
    DRM_BYTE* Data();
    bool Empty();
    bool IsGuid() { return keyIdOrder == KEYID_ORDER_GUID_LE; }

    // Both guid and uuid formats are checked during this operation.
    bool operator==( const KeyId &keyId );
    bool operator<( const KeyId &keyId ) const;
    bool operator!=( const KeyId &keyId )
    {
        return !( operator==(keyId) );
    };

private:
    std::string m_base64Str;

    std::string m_hexStr;

    DRM_BYTE m_bytes[ DRM_ID_SIZE ];

    KeyIdOrder keyIdOrder;
};

// This contains the data that is stored for a decrypt context in the
// vector.
struct __DECRYPT_CONTEXT
{
    PR4Util::KeyId keyId;
    DRM_DECRYPT_CONTEXT oDrmDecryptContext;

    __DECRYPT_CONTEXT()
    {
        memset( &oDrmDecryptContext, 0, sizeof( DRM_DECRYPT_CONTEXT ) );
    }
};

// typedef the above struct as a shared_ptr to be the actual vector item.  Use share_ptr
// here in case a reference to decryptor is being used so it does not go out of
// scope.
typedef std::shared_ptr<PR4Util::__DECRYPT_CONTEXT> DECRYPT_CONTEXT;

// Create a vector item
#define NEW_DECRYPT_CONTEXT() std::make_shared<PR4Util::__DECRYPT_CONTEXT>()

}; // namespace PR4Utils

#endif /* PR4UTIL_H_ */
